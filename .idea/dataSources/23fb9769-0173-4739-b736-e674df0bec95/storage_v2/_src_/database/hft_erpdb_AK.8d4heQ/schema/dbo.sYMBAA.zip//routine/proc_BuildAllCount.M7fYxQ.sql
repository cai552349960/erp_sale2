CREATE PROCEDURE [dbo].[proc_BuildAllCount]
@bulid_id VARCHAR(60), --楼盘ID或者楼盘名称模糊匹配
@caseType VARCHAR(10), --统计出售或者出租
@yearStr  VARCHAR(10), --年份
@useAgeSql VARCHAR(500) --用途 SQL条件的字符串 例:SALE_USEAGE = 'HOUSING'  AND SALE_UNIT_PRICE <= 20000(当用途为住宅时值统计单价不超过20000的 )  不能为空字符串 和单价限制条件
AS
BEGIN
SET NOCOUNT ON;
CREATE TABLE #TMP_A(
PRICE FLOAT,
FIT VARCHAR(30),
AREA INT,
HOUSE_FLOOR INT,
MONTH_VALUE INT
)
CREATE TABLE #TMP_A1(
PRICE FLOAT,
FIT VARCHAR(30),
AREA INT,
HOUSE_FLOOR INT,
MONTH_VALUE INT
)
CREATE TABLE #tmpB(
SUM_V INT NULL,
AVG_V FLOAT NULL,
MONTHF VARCHAR(5) NULL
)
DECLARE @condCaseTye VARCHAR(10) ,
@MonthStr INT = 1,
@SDATE VARCHAR(40),
@EDATE VARCHAR(40),
@sqlStr NVARCHAR(500),
@sqlStrInto NVARCHAR(100),
@conditionA VARCHAR(150),
@conditionB VARCHAR(10),
@dateCondition VARCHAR(100),
@count INT = 0, --判断是添加还是插入
@sumV INT,
@avgV FLOAT,
@monV VARCHAR(5),
@sqlS2 NVARCHAR(500),
@type VARCHAR(100)
IF @caseType = '1'
BEGIN
SET @type = 'CASE_TYPE IN (''1'',''5'')'
END
ELSE IF @caseType = '2'
BEGIN
SET @type = 'CASE_TYPE IN (''2'',''6'')'
END
ELSE
BEGIN
SET @type = 'CASE_TYPE = '''+@caseType+''''
END;
SET @sqlS2 = 'INSERT INTO #TMP_A1(PRICE,FIT,AREA,HOUSE_FLOOR,MONTH_VALUE) SELECT PRICE,FITMENT AS FIT,FLOOR(AREA),null,DATEPART(MONTH,CREATE_DATE) FROM FUN_ALL_COUNTDATA WHERE ' + @useAgeSql + ' AND CREATE_DATE BETWEEN ''' +  @yearStr + '-01-01' + ''' AND '''+ @yearStr +'-12-31 23:59:59 ''' + @bulid_id + ' AND '+@type;
EXEC sp_executesql @sqlS2;
INSERT INTO #TMP_A(PRICE,FIT,AREA,HOUSE_FLOOR,MONTH_VALUE) SELECT AVG(PRICE),FIT,FLOOR(AREA),HOUSE_FLOOR,MONTH_VALUE FROM #TMP_A1 GROUP BY FIT,AREA,HOUSE_FLOOR,MONTH_VALUE
SET @conditionA = '@sumV = CONVERT(INT,ISNULL(COUNT(''X''),0)), @avgV = CONVERT(FLOAT,ROUND(ISNULL(AVG(PRICE), 0),1)),';
WHILE  @MonthStr <= 12
BEGIN
SET @sqlStr = 'SELECT ' + @conditionA + '@monV = ' + CONVERT(VARCHAR(2),@MonthStr) + ' FROM #TMP_A WHERE MONTH_VALUE = @MonthStr';
EXEC sp_executesql @sqlStr,N'@MonthStr INT,@sumV INT output,@avgV FLOAT output,@monV VARCHAR(5) output',@MonthStr,@sumV output,@avgV output,@monV output;
SET @sqlStrInto = 'INSERT INTO #tmpB(SUM_V,AVG_V,MONTHF)VALUES('+CONVERT(VARCHAR(10),@sumV)+','+CONVERT(VARCHAR(10),@avgV)+','''+@monV+''')';
EXEC sp_executesql @sqlStrInto;
SET @MonthStr = @MonthStr + 1
END
SELECT * FROM #tmpB;
DROP TABLE #tmpB;
DROP TABLE #TMP_A1;
DROP TABLE #TMP_A;
END

go

