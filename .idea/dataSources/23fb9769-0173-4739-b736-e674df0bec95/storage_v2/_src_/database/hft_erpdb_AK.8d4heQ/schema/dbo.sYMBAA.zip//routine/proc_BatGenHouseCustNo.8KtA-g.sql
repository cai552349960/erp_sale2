
-- =============================================
-- Author:		顾灿龙
-- Create date: 2014-02-24
-- Description:	批量生成房客源NO，规则：2位类型+2位城市编号+YYMMDD+7位自增序列，共17位房客源编码
-- =============================================

CREATE PROCEDURE [dbo].[proc_BatGenHouseCustNo]
	@TableName	varchar(20),  --表名
	@CityNo		varchar(10),  --城市编号
	@GenNums    INT           --批量生存编号数量
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE @NoType VARCHAR(20)	
	DECLARE @DATESTR VARCHAR(10)
	DECLARE @GenSeq TABLE(SeqNo INT)

	SELECT @NoType = CASE upper(@TableName) 
			WHEN 'FUN_SALE'		THEN 'CS'
			WHEN 'FUN_LEASE'	THEN 'CZ'
			WHEN 'FUN_BUY_CUSTOMER'		THEN 'QG'
			WHEN 'FUN_RENT_CUSTOMER'	THEN 'QZ'
			ELSE '' END

	IF @NoType = ''OR ISNULL(@CityNo,'') = '' RETURN 

	--获取YYMMDDHHMMSS
	SELECT @DATESTR = substring(convert(varchar(20),getdate(),112),3,6);

	--递归产生@GenNums个记录
	WITH MySeq (RowNumber) AS
		(SELECT 1
		 UNION ALL
		 SELECT RowNumber + 1
		 FROM MySeq 
		 WHERE RowNumber < @GenNums )

	INSERT @GenSeq(SeqNo)
	SELECT RowNumber FROM MySeq OPTION (MAXRECURSION 0);

	--从自增序列获取流水号，该流水号范围2400001 - 9999999，每天零点由作业自动初始化成2400001
	SELECT @NoType + upper(@CityNo) + @DATESTR + convert(varchar(7),NEXT VALUE FOR SQ_BatHouseCustNo) AS HouseCustNo from @GenSeq

END

go

