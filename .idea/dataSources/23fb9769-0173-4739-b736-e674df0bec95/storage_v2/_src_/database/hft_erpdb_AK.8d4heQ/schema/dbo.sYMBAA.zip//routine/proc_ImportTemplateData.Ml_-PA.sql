-- =============================================
-- Author:		Allen
-- Create date: 2015-10-16
-- Description:	试用公司模板数据导入
-- =============================================
CREATE PROCEDURE [dbo].[proc_ImportTemplateData]
	@compNo varchar(10),
	@deptNo varchar(10)
AS
BEGIN
	SET NOCOUNT ON
	
	if len(@compNo) = 0 or LEN(@deptNo) = 0
		return
    
	declare @caseId int, @compId int, @cityId int, @areaId int, @regId int, @deptId int, @grId int, @userId int, @archiveId int, @userName varchar(30),
	@buildId int, @buildName varchar(50), @buildCode varchar(15), @saleReg int, @regionName varchar(30), @sectionId int, @sectionName varchar(30),
	@saleRound int, @plateType VARCHAR(30), @userCount int, @maxUserId int,
	@saleId int, @leaseId int, @buyCustId int, @rentCustId int,
	@saleNo varchar(20), @leaseNo varchar(20), @buyCustNo varchar(20), @rentCustNo varchar(20),
	@housePlate tinyint, @custPlate tinyint, @buildCount int, @maxBuildId int, @photoId int, @videoId int, @tmpPhotoId int, @trydataImported tinyint,
	@vrPhotoId int
	

	--在admin库判断门店是否符合条件
	select @compId = COMP_ID, @trydataImported = TRYDATA_IMPORTED from hft_admindb..FUN_DEPTS where COMP_NO = @compNo and DEPT_NO = @deptNo AND DEPT_FLAG = 1
	if @compId is null
	begin
		select 'NO_COMP' as result
		return
	end
	if @trydataImported is null or @trydataImported = 1
	begin
		select 'ALREADY_IMPORT' as result
		return
	end

	select @compId = COMP_ID, @areaId = AREA_ID, @regId = REG_ID, @deptId = DEPT_ID from FUN_DEPTS where COMP_NO = @compNo and DEPT_NO = @deptNo AND DEPT_FLAG = 1
	
	select @cityId = CITY_ID from hft_admindb..FUN_DEPTS where COMP_NO = @compNo and DEPT_NO = @deptNo

	select @plateType = param_value from SYS_PARA where COMP_ID = @compId and PARAM_ID = 'SYSTEM_RUN_MODEL'
	if(@plateType = 'PUBLIC' or @plateType = 'PUBFUN')
		set @housePlate = 3
	else
		set @housePlate = 2
		
	if(@plateType = 'PUBLIC' or @plateType = 'PUBCUST')
		set @custPlate = 3
	else
		set @custPlate = 2

	set @userId = 0
	set @archiveId = 0
	select @userCount = COUNT(*), @maxUserId = MAX(USER_ID) from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0
	if @userCount = 0
		return

	set @buildId = 0
	select @buildCount = COUNT(*), @maxBuildId = MAX(BUILD_ID) from hft_admindb..TEMPLATE_BUILDING_INFO WHERE CITY_ID = @cityId

	--出售房源初始化
	declare saleCursor cursor
	for select SALE_ID from HFT_ADMINDB..TEMPLATE_FUN_SALE
	OPEN saleCursor

	fetch next from saleCursor into @caseId
	while @@FETCH_STATUS = 0
	begin
		if @userCount > 1
		begin
			if @maxUserId = @userId 
				set @userId = 0
			select top 1 @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0 and USER_ID > @userId order by USER_ID
		end
		else
			select @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0
		
		if @buildCount > 0
		begin
			if @maxBuildId = @buildId
				set @buildId = 0
		
			select @buildId = A.BUILD_ID, @buildName = A.BUILD_NAME+'(测试)', @saleReg = A.BUILD_REGION, @sectionId = A.SECTION_ID, 
				@saleRound = A.BUILD_ROUND, @regionName = C.REG_NAME, @sectionName = D.SECTION_NAME from BUILDING_INFO A 
				LEFT JOIN hft_admindb..TEMPLATE_BUILDING_INFO B ON A.BUILD_ID = B.BUILD_ID AND A.CITY_ID = B.CITY_ID 
				LEFT JOIN hft_admindb..FUN_REG C ON A.BUILD_REGION = C.REG_ID
				LEFT JOIN FUN_SECTION D ON A.SECTION_ID = D.SECTION_ID
				where B.CITY_ID = @cityId and B.BUILD_ID > @buildId
		end
		else
		begin
			set @buildId = null; set @buildName = null; set @buildCode = null; set @saleReg = null; 
			set @regionName = null; set @sectionId = null; set @sectionName = null; set @saleRound = null
		end
		
		select @saleId = (next value for SEQ_FUN_SALE_SALE_ID)
		--exec proc_GenHouseCustNo 'FUN_SALE', @cityId, @saleNo output
		
		select @saleNo = 'CS' + upper(COMP_NO) + substring(replace(convert(varchar(20),getdate(),112) + convert(varchar(20),getdate(),108),':',''),3,10) + 
		substring(convert(varchar(4),1000 + NEXT VALUE FOR SQ_HouseCustNo ),2,3) 
		from hft_admindb..FUN_CITY where CITY_ID = @cityId
		
		insert into FUN_SALE(SALE_ID,COMP_ID,CITY_ID,REG_ID ,DEPT_ID,GR_ID,USER_ID,ARCHIVE_ID,CREATION_TIME,CREATE_ARCHIVE_ID,SALE_NO,SALE_OWNER,CELL_PHONE,ID_CARD,SALE_SUBJECT,BUILD_ID,
			BUILD_NAME,BUILD_CODE,SALE_REG,REGION_NAME,SECTION_ID,SECTION_NAME,SALE_ROUND,TRADE_ADDR,SALE_ROOF,SALE_UNIT,UNIT_FLOOR,SALE_NUM,SALE_ROOF_R,SALE_UNIT_R,
			UNIT_FLOOR_R,SALE_NUM_R,SALE_LADDER,SALE_DOORS,SALE_ROOM,SALE_HALL,SALE_WEI,SALE_YANG,SALE_TYPE,SALE_FLOOR,SALE_FLOORS,SALE_FITMENT,SALE_DIRECT,SALE_YEAR,
			SALE_STRUCT,SALE_USEAGE,SHOP_USAGE,OWNER_TYPE,OFFICE_LEVEL,SALE_STREET,SALE_RIGHT,SALE_MORTGAGE,SALE_ACCOUNT,SALE_AREA,SALE_TOTAL_PRICE,SALE_UNIT_PRICE,
			SALE_LOWEST_PRICE,SALE_PROPERTY,IS_SEPERATOR,SALE_LEAVE_TIME,HALL_STRUCTURE,UG_AREA,UG_TYPE,GARDEN_AREA,GARAGE_AMOUNT,SALE_CHARACT,SALE_MEMO,SALE_SOURCE,
			SALE_KEY,SALE_KEY_NUM,KEY_TIME,SALE_EXPLRTH,EXPLRTH_DATETIME,SALE_CONSIGN,SALE_CONSIGN_NO,WEITUO_TIME,SALE_COOPERATE,SALE_PUBLISH,SALE_MAP,SALE_LEVEL,
			PLATE_TYPE,SALE_STATUS,TRACK_TIME,TRACK_TIME2,ACTION_TIME,FROM_SOSO,REPEAT_FLAG,INFO_TYPE,SHARE_FLAG,FRIEND_HOUSE,COOPERATE_TIME,COMPLAINT_FLAG,PUBLISH_TIME,
			PHOTO_TIME,RED_FLAG,ORANGE_FLAG,PUBLIC_COUNT,PUBLIC_TIME,SPECIAL_TIME,SCHEDULE_TIME,DEAL_TIME,WRITEOFF_TIME,SECRECY_TIME,COMMEND_TIME,PRIVATE_TIME,
			FROM_PUBLIC,THUMB_URL,UPDATE_TIME,TAG_IDS,SALE_CERT_TIME,PUBLISH_SITES,AREA_ID,SALE_ROOF_T,SALE_NUM_T,SALE_UNIT_T,VIDEO_NUM,CREATOR_UID,
			SALE_INNERAREA,HOUSE_BARGAIN,TRUE_FLAG,SENDTOTENCENT, is_ignore,SENDTO_YOUYOU,PANORAMA_MAP)
			
			select @saleId,@compId,@cityId,@regId,@deptId,@grId,@userId,@archiveId,GETDATE(),@archiveId,@saleNo,SALE_OWNER+'(测试)' SALE_OWNER , CELL_PHONE,ID_CARD,SALE_SUBJECT,@buildId,
			@buildName,@buildCode,@saleReg,@regionName,@sectionId,@sectionName,@saleRound,TRADE_ADDR,SALE_ROOF,SALE_UNIT,UNIT_FLOOR,SALE_NUM,SALE_ROOF_R,SALE_UNIT_R,
			UNIT_FLOOR_R,SALE_NUM_R,SALE_LADDER,SALE_DOORS,SALE_ROOM,SALE_HALL,SALE_WEI,SALE_YANG,SALE_TYPE,SALE_FLOOR,SALE_FLOORS,SALE_FITMENT,SALE_DIRECT,SALE_YEAR,
			SALE_STRUCT,SALE_USEAGE,SHOP_USAGE,OWNER_TYPE,OFFICE_LEVEL,SALE_STREET,SALE_RIGHT,SALE_MORTGAGE,SALE_ACCOUNT,SALE_AREA,SALE_TOTAL_PRICE,SALE_UNIT_PRICE,
			SALE_LOWEST_PRICE,SALE_PROPERTY,IS_SEPERATOR,SALE_LEAVE_TIME,HALL_STRUCTURE,UG_AREA,UG_TYPE,GARDEN_AREA,GARAGE_AMOUNT,SALE_CHARACT,SALE_MEMO,SALE_SOURCE,
			SALE_KEY,SALE_KEY_NUM,KEY_TIME,SALE_EXPLRTH,EXPLRTH_DATETIME,SALE_CONSIGN,SALE_CONSIGN_NO,WEITUO_TIME,SALE_COOPERATE,0 as SALE_PUBLISH,SALE_MAP,SALE_LEVEL,
			@housePlate,SALE_STATUS,GETDATE(),null,GETDATE(),FROM_SOSO,REPEAT_FLAG,0,0,0,null,COMPLAINT_FLAG,PUBLISH_TIME,
			PHOTO_TIME,0,0,0,null,null,null,null,null,null,null,null,
			0,THUMB_URL,GETDATE(),TAG_IDS,null,PUBLISH_SITES,@areaId,SALE_ROOF_T,SALE_NUM_T,SALE_UNIT_T,VIDEO_NUM,@userId,
			SALE_INNERAREA,0,0,0, 2,0,PANORAMA_MAP
			from hft_admindb..TEMPLATE_FUN_SALE WHERE SALE_ID = @caseId
			
			--跟进
			
			insert into FUN_TRACK
			(TRACK_ID, COMP_ID, DEPT_ID, CASE_TYPE, CASE_ID, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
			TRACK_CONTENT, TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, CREATION_TIME, USEAGE, CASE_NO, TARGET_USEAGE, INDEX_SHOW, KEY_NUM, TARGET_DEPT, INCLUDE_TRACK, TRACK_RESULT) 
				select (NEXT VALUE FOR SEQ_FUN_TRACK_TRACK_ID), @compId, @deptId, CASE_TYPE, @saleId, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
				@userName + SUBSTRING(TRACK_CONTENT, CHARINDEX('于本日', TRACK_CONTENT, 0), LEN(TRACK_CONTENT)), TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, GETDATE(), USEAGE, @saleNo, null, 0, null, null, INCLUDE_TRACK, null
				FROM hft_admindb..TEMPLATE_FUN_TRACK where CASE_TYPE = 1 and CASE_ID = @caseId AND TRACK_CLASSIC = '[ 房源登记 ]'
			
			--图片
			declare photoCursor cursor
			for select PHOTO_ID from HFT_ADMINDB..TEMPLATE_FUN_PHOTO where CASE_ID = @caseId and CASE_TYPE = 1
			OPEN photoCursor
			fetch next from photoCursor into @tmpPhotoId
			WHILE @@FETCH_STATUS = 0
			BEGIN
				select @photoId = (next value for SEQ_FUN_PHOTO_PHOTO_ID)
				insert into FUN_PHOTO(PHOTO_ID, COMP_ID, CASE_ID, CASE_TYPE, PHOTO_ADDR, PHOTO_TYPE, USEAGE_TYPE, PD_ID, UPLOAD_USER, UPLOAD_DATE, IS_TOP, PHOTO_SOURCE, TRANSMIT_FLAG, PHOTO_SEQ)
				SELECT @photoId, @compId, @saleId, CASE_TYPE, PHOTO_ADDR, PHOTO_TYPE, USEAGE_TYPE, PD_ID, @userId, GETDATE(), IS_TOP, PHOTO_SOURCE, 0, PHOTO_SEQ 
				FROM hft_admindb..TEMPLATE_FUN_PHOTO where PHOTO_ID = @tmpPhotoId
				fetch next from photoCursor into @tmpPhotoId
			END
			CLOSE photoCursor
			DEALLOCATE photoCursor
			
			--视频
			select @videoId = (next value for SEQ_FUN_VIDEO_VIDEO_ID)
			insert into FUN_VIDEO(VIDEO_ID, CASE_ID, CASE_TYPE, VIDEO_ADDR, PHOTO_ADDR, TORRENT_ADDR, VIDEO_MD5, VIDEO_TYPE, VIDEO_STATUS, 
			UPLOAD_USER, ARCHIVE_ID, UPLOAD_DATE, VIDEO_DESC, TX_VID)
			SELECT TOP 1 @videoId, @saleId, CASE_TYPE, VIDEO_ADDR, PHOTO_ADDR, TORRENT_ADDR, VIDEO_MD5, VIDEO_TYPE, VIDEO_STATUS, @userId, @archiveId,
			 GETDATE(), VIDEO_DESC, TX_VID 
			FROM hft_admindb..TEMPLATE_FUN_VIDEO where CASE_ID = @caseId and CASE_TYPE = 1 AND VIDEO_STATUS = 0
		
			--VR 
			insert into FUN_PANORAMA_PHOTO(PHOTO_ID,COMP_ID,CASE_ID,CASE_TYPE,PHOTO_ADDR,UPLOAD_USER,ARCHIVE_ID,UPLOAD_DATE,SCENE,
			CFOV, PHOTO_STATUS, CASE_NO, SOURCE, VR_REVIEW_FLAG, UPLOAD_CLIENT_ID)  
			SELECT (next value for SEQ_FUN_PANORAMA_PHOTO_PHOTO_ID),@compId, @saleId, CASE_TYPE,PHOTO_ADDR,@userId,@archiveId, UPLOAD_DATE,SCENE,CFOV,PHOTO_STATUS,@saleNo,
			SOURCE,VR_REVIEW_FLAG,UPLOAD_CLIENT_ID 
			FROM hft_admindb..TEMPLATE_FUN_PANORAMA_PHOTO WHERE CASE_ID = @caseId and CASE_TYPE = 1 AND PHOTO_STATUS=0 

		fetch next from saleCursor INTO @caseId
	end
	close saleCursor
	deallocate saleCursor


	set @userId = 0; set @buildId = 0

	--出租房源初始化
	declare leaseCursor cursor
	for select LEASE_ID from HFT_ADMINDB..TEMPLATE_FUN_LEASE
	OPEN leaseCursor

	fetch next from leaseCursor into @caseId
	while @@FETCH_STATUS = 0
	begin
		if @userCount > 1
		begin
			if @maxUserId = @userId 
				set @userId = 0
			select top 1 @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0 and USER_ID > @userId order by USER_ID
		end
		else
			select @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0
		
		
		if @buildCount > 0
		begin
			if @maxBuildId = @buildId
				set @buildId = 0
		
			select @buildId = A.BUILD_ID, @buildName = A.BUILD_NAME+'(测试)', @saleReg = A.BUILD_REGION, @sectionId = A.SECTION_ID, 
				@saleRound = A.BUILD_ROUND, @regionName = C.REG_NAME, @sectionName = D.SECTION_NAME from BUILDING_INFO A 
				LEFT JOIN hft_admindb..TEMPLATE_BUILDING_INFO B ON A.BUILD_ID = B.BUILD_ID AND A.CITY_ID = B.CITY_ID 
				LEFT JOIN hft_admindb..FUN_REG C ON A.BUILD_REGION = C.REG_ID
				LEFT JOIN FUN_SECTION D ON A.SECTION_ID = D.SECTION_ID
				where B.CITY_ID = @cityId and B.BUILD_ID > @buildId
		end
		else
		begin
			set @buildId = null; set @buildName = null; set @buildCode = null; set @saleReg = null; 
			set @regionName = null; set @sectionId = null; set @sectionName = null; set @saleRound = null
		end
		
		select @leaseId = (next value for SEQ_FUN_LEASE_LEASE_ID)
--		exec proc_GenHouseCustNo 'FUN_LEASE', @cityId, @leaseNo output
				
		select @leaseNo = 'CZ' + upper(COMP_NO) + substring(replace(convert(varchar(20),getdate(),112) + convert(varchar(20),getdate(),108),':',''),3,10) + 
		substring(convert(varchar(4),1000 + NEXT VALUE FOR SQ_HouseCustNo ),2,3) 
		from hft_admindb..FUN_CITY where CITY_ID = @cityId
		
		insert into FUN_LEASE(LEASE_ID, COMP_ID, CITY_ID, REG_ID, DEPT_ID, GR_ID, USER_ID, ARCHIVE_ID, CREATION_TIME, CREATE_ARCHIVE_ID, LEASE_NO, LEASE_SUBJECT, LEASE_OWNER, CELL_PHONE, ID_CARD, 
			BUILD_ID, BUILD_NAME, BUILD_CODE, LEASE_REG, REGION_NAME, SECTION_ID, SECTION_NAME, LEASE_ROUND, TRADE_ADDR, LEASE_ROOF, LEASE_UNIT, UNIT_FLOOR, LEASE_NUM, LEASE_ROOF_R, 
			LEASE_UNIT_R, UNIT_FLOOR_R, LEASE_NUM_R, PLATE_TYPE, LEASE_ROOM, LEASE_HALL, LEASE_WEI, LEASE_YANG, LEASE_LADDER, LEASE_DOORS, LEASE_TYPE, LEASE_FLOOR, LEASE_FLOORS, 
			LEASE_FITMENT, LEASE_DIRECT, LEASE_YEAR, LEASE_USEAGE, LEASE_STREET, LEASE_ACCOUNT, LEASE_AREA, LEASE_TOTAL_PRICE, PRICE_UNIT, LEASE_LOWEST_PRICE, LEASE_PROPERTY, 
			IS_SEPERATOR, SHOP_USAGE, OWNER_TYPE, OFFICE_LEVEL, LEASE_DEPOSIT, LEASE_LEAVE_TIME, LEASE_LIMITE, HALL_STRUCTURE, UG_AREA, UG_TYPE, GARDEN_AREA, GARAGE_AMOUNT, 
			LEASE_SET, LEASE_CHARACT, LEASE_MEMO, LEASE_SOURCE, LEASE_LEVEL, LEASE_KEY, LEASE_KEY_NUM, KEY_TIME, LEASE_EXPLRTH, EXPLRTH_DATETIME, LEASE_CONSIGN, LEASE_CONSIGN_NO, 
			WEITUO_TIME, LEASE_COOPERATE, COOPERATE_TIME, COMPLAINT_FLAG, LEASE_PUBLISH, PUBLISH_TIME, LEASE_MAP, PHOTO_TIME, LEASE_STATUS, TRACK_TIME, TRACK_TIME2, ACTION_TIME, 
			FROM_SOSO, REPEAT_FLAG, INFO_TYPE, SHARE_FLAG, FRIEND_HOUSE, RED_FLAG, ORANGE_FLAG, PUBLIC_COUNT, PUBLIC_TIME, DUE_TIME, SPECIAL_TIME, SCHEDULE_TIME, DEAL_TIME, WRITEOFF_TIME, 
			SECRECY_TIME, COMMEND_TIME, PRIVATE_TIME, FROM_PUBLIC, THUMB_URL, UPDATE_TIME, TAG_IDS, LEASE_CERT_TIME, PUBLISH_SITES, AREA_ID, LEASE_ROOF_T, LEASE_NUM_T, LEASE_UNIT_T, 
			VIDEO_NUM, CREATOR_UID, LEASE_INNERAREA, HOUSE_BARGAIN, TRUE_FLAG, SENDTOTENCENT, is_ignore,SENDTO_YOUYOU,PANORAMA_MAP)
			
			select @leaseId, @compId, @cityId, @regId, @deptId, @grId, @userId, @archiveId, GETDATE(), @archiveId, @leaseNo, LEASE_SUBJECT, LEASE_OWNER+'(测试)' LEASE_OWNER,  CELL_PHONE, ID_CARD, 
			@buildId, @buildName, @buildCode, @saleReg, @regionName, @sectionId, @sectionName, @saleRound, null, LEASE_ROOF, LEASE_UNIT, UNIT_FLOOR, LEASE_NUM, LEASE_ROOF_R, 
			LEASE_UNIT_R, UNIT_FLOOR_R, LEASE_NUM_R, @housePlate, LEASE_ROOM, LEASE_HALL, LEASE_WEI, LEASE_YANG, LEASE_LADDER, LEASE_DOORS, LEASE_TYPE, LEASE_FLOOR, LEASE_FLOORS, 
			LEASE_FITMENT, LEASE_DIRECT, LEASE_YEAR, LEASE_USEAGE, LEASE_STREET, LEASE_ACCOUNT, LEASE_AREA, LEASE_TOTAL_PRICE, PRICE_UNIT, LEASE_LOWEST_PRICE, LEASE_PROPERTY, 
			IS_SEPERATOR, SHOP_USAGE, OWNER_TYPE, OFFICE_LEVEL, LEASE_DEPOSIT, LEASE_LEAVE_TIME, LEASE_LIMITE, HALL_STRUCTURE, UG_AREA, UG_TYPE, GARDEN_AREA, GARAGE_AMOUNT, 
			LEASE_SET, LEASE_CHARACT, LEASE_MEMO, LEASE_SOURCE, LEASE_LEVEL, LEASE_KEY, LEASE_KEY_NUM, KEY_TIME, LEASE_EXPLRTH, EXPLRTH_DATETIME, LEASE_CONSIGN, LEASE_CONSIGN_NO, 
			WEITUO_TIME, LEASE_COOPERATE, COOPERATE_TIME, COMPLAINT_FLAG, 0 as LEASE_PUBLISH, PUBLISH_TIME, LEASE_MAP, PHOTO_TIME, LEASE_STATUS, GETDATE(), null, GETDATE(), 
			FROM_SOSO, REPEAT_FLAG, 0, 0, 0, 0, 0, 0, null, null, null, null, null, null, 
			null, null, null, 0, THUMB_URL, GETDATE(), TAG_IDS, null, PUBLISH_SITES, @areaId, LEASE_ROOF_T, LEASE_NUM_T, LEASE_UNIT_T, 
			VIDEO_NUM, @userId, LEASE_INNERAREA, 0, 0, 0, 2,0,PANORAMA_MAP
			from hft_admindb..TEMPLATE_FUN_LEASE WHERE LEASE_ID = @caseId
			
			--跟进
			insert into FUN_TRACK
			(TRACK_ID, COMP_ID, DEPT_ID, CASE_TYPE, CASE_ID, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
			TRACK_CONTENT, TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, CREATION_TIME, USEAGE, CASE_NO, TARGET_USEAGE, INDEX_SHOW, KEY_NUM, TARGET_DEPT, INCLUDE_TRACK, TRACK_RESULT) 
				select (NEXT VALUE FOR SEQ_FUN_TRACK_TRACK_ID), @compId, @deptId, CASE_TYPE, @leaseId, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
				@userName + SUBSTRING(TRACK_CONTENT, CHARINDEX('于本日', TRACK_CONTENT, 0), LEN(TRACK_CONTENT)), TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, GETDATE(), USEAGE, @leaseNo, null, 0, null, null, INCLUDE_TRACK, null
				FROM hft_admindb..TEMPLATE_FUN_TRACK where CASE_TYPE = 2 and CASE_ID = @caseId AND TRACK_CLASSIC = '[ 房源登记 ]'
			
			--图片
			declare photoCursor cursor
			for select PHOTO_ID from HFT_ADMINDB..TEMPLATE_FUN_PHOTO where CASE_ID = @caseId and CASE_TYPE = 2
			OPEN photoCursor
			fetch next from photoCursor into @tmpPhotoId
			WHILE @@FETCH_STATUS = 0
			BEGIN
				select @photoId = (next value for SEQ_FUN_PHOTO_PHOTO_ID)
				insert into FUN_PHOTO(PHOTO_ID, COMP_ID, CASE_ID, CASE_TYPE, PHOTO_ADDR, PHOTO_TYPE, USEAGE_TYPE, PD_ID, UPLOAD_USER, UPLOAD_DATE, IS_TOP, PHOTO_SOURCE, TRANSMIT_FLAG, PHOTO_SEQ)
				SELECT @photoId, @compId, @leaseId, CASE_TYPE, PHOTO_ADDR, PHOTO_TYPE, USEAGE_TYPE, PD_ID, @userId, GETDATE(), IS_TOP, PHOTO_SOURCE, 0, PHOTO_SEQ 
				FROM hft_admindb..TEMPLATE_FUN_PHOTO where PHOTO_ID = @tmpPhotoId
				fetch next from photoCursor into @tmpPhotoId
			END
			CLOSE photoCursor
			DEALLOCATE photoCursor
			
			--视频
			select @videoId = (next value for SEQ_FUN_VIDEO_VIDEO_ID)
			insert into FUN_VIDEO(VIDEO_ID, CASE_ID, CASE_TYPE, VIDEO_ADDR, PHOTO_ADDR, TORRENT_ADDR, VIDEO_MD5, VIDEO_TYPE, VIDEO_STATUS, UPLOAD_USER, ARCHIVE_ID, UPLOAD_DATE, VIDEO_DESC, TX_VID)
			SELECT TOP 1 @videoId, @leaseId, CASE_TYPE, VIDEO_ADDR, PHOTO_ADDR, TORRENT_ADDR, VIDEO_MD5, VIDEO_TYPE, VIDEO_STATUS, @userId, @archiveId, GETDATE(), VIDEO_DESC, TX_VID 
			FROM hft_admindb..TEMPLATE_FUN_VIDEO where CASE_ID = @caseId and CASE_TYPE = 2 AND VIDEO_STATUS = 0
			
			--VR 
			insert into FUN_PANORAMA_PHOTO(PHOTO_ID,COMP_ID,CASE_ID,CASE_TYPE,PHOTO_ADDR,UPLOAD_USER,ARCHIVE_ID,UPLOAD_DATE,SCENE,
			CFOV, PHOTO_STATUS, CASE_NO, SOURCE, VR_REVIEW_FLAG, UPLOAD_CLIENT_ID)  
			SELECT (next value for SEQ_FUN_PANORAMA_PHOTO_PHOTO_ID),@compId, @leaseId, CASE_TYPE,PHOTO_ADDR,@userId,@archiveId, UPLOAD_DATE,SCENE,CFOV,PHOTO_STATUS,@leaseNo,
			SOURCE,VR_REVIEW_FLAG,UPLOAD_CLIENT_ID 
			FROM hft_admindb..TEMPLATE_FUN_PANORAMA_PHOTO WHERE CASE_ID = @caseId and CASE_TYPE = 2 AND PHOTO_STATUS=0 

		fetch next from leaseCursor INTO @caseId
	end
	close leaseCursor
	deallocate leaseCursor


	set @userId = 0; set @buildId = 0

	--求购客户初始化
	declare buyCursor cursor
	for select BUY_CUST_ID from HFT_ADMINDB..TEMPLATE_FUN_BUY_CUSTOMER
	OPEN buyCursor

	fetch next from buyCursor into @caseId
	while @@FETCH_STATUS = 0
	begin
		if @userCount > 1
		begin
			if @maxUserId = @userId 
				set @userId = 0
			select top 1 @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0 and USER_ID > @userId order by USER_ID
		end
		else
			select @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0
		
		
		if @buildCount > 0
		begin
			if @maxBuildId = @buildId
				set @buildId = 0
		
			select @buildId = A.BUILD_ID, @buildName = A.BUILD_NAME+'(测试)', @saleReg = A.BUILD_REGION, @sectionId = A.SECTION_ID, 
				@saleRound = A.BUILD_ROUND, @regionName = C.REG_NAME, @sectionName = D.SECTION_NAME from BUILDING_INFO A 
				LEFT JOIN hft_admindb..TEMPLATE_BUILDING_INFO B ON A.BUILD_ID = B.BUILD_ID AND A.CITY_ID = B.CITY_ID 
				LEFT JOIN hft_admindb..FUN_REG C ON A.BUILD_REGION = C.REG_ID
				LEFT JOIN FUN_SECTION D ON A.SECTION_ID = D.SECTION_ID
				where B.CITY_ID = @cityId and B.BUILD_ID > @buildId
		end
		else
		begin
			set @buildId = null; set @buildName = null; set @buildCode = null; set @saleReg = null; 
			set @regionName = null; set @sectionId = null; set @sectionName = null; set @saleRound = null
		end
		
		select @buyCustId = (next value for SEQ_FUN_BUY_CUSTOMER_BUY_CUST_ID)
--		exec proc_GenHouseCustNo 'FUN_BUY_CUSTOMER', @cityId, @buyCustNo output
		
		select @buyCustNo = 'QG' + upper(COMP_NO) + substring(replace(convert(varchar(20),getdate(),112) + convert(varchar(20),getdate(),108),':',''),3,10) + 
		substring(convert(varchar(4),1000 + NEXT VALUE FOR SQ_HouseCustNo ),2,3) 
		from hft_admindb..FUN_CITY where CITY_ID = @cityId
		
		insert into FUN_BUY_CUSTOMER
			(BUY_CUST_ID, CITY_ID, REG_ID, COMP_ID, DEPT_ID, GR_ID, USER_ID, ARCHIVE_ID, CREATION_TIME, CREATOR_UID, CREATE_ARCHIVE_ID, BUY_CUST_NO, BUY_CUST_NAME, BUY_CUST_SEX, 
			BUY_CUST_AGE, BUY_CUST_CAREER, CELL_PHONE, ID_CARD, CUST_ADDR, BUY_LIFEBOUND, BUY_GOAL, BUY_LENGTH, BUY_ABILITY, BUY_PAYTYPE, CUST_LEVEL, PLATE_TYPE, BUY_CUST_SOURCE, 
			BUY_CUST_LEVEL, HOUSE_ROOM, HOUSE_ROOM_1, HOUSE_REGION, REGION_NAME, SECTION_ID, SECTION_NAME, BUILD_ID, BUILD_NAME, HOUSE_ROUND, HOUSE_TYPE, HOUSE_USEAGE, HOUSE_FITMENT, 
			HOUSE_DIRECT, HOUSE_FLOOR_LOW, HOUSE_FLOOR_HIGH, HOUSE_PRICE_LOW, HOUSE_PRICE_HIGH, HOUSE_AREA_LOW, HOUSE_AREA_HIGH, HOUSE_YEAR_LOW, HOUSE_YEAR_HIGH, HOUSE_LOOK, CUST_REQUEST, 
			CUST_MEMO, BUY_CUST_STATUS, TRACK_TIME, REPEAT_FLAG, INFO_TYPE, SHARE_FLAG, RED_FLAG, ORANGE_FLAG, PUBLIC_COUNT, PUBLIC_TIME, SPECIAL_TIME, SCHEDULE_TIME, DEAL_TIME, 
			WRITEOFF_TIME, SECRECY_TIME, COMMEND_TIME, ACTION_TIME, PRIVATE_TIME, FROM_PUBLIC, COOPERATE_FLAG, UPDATE_TIME, FRIEND_HOUSE, COOPERATE_TIME, COMPLAINT_FLAG, AREA_ID, is_ignore)
		select @buyCustId, @cityId, @regId, @compId, @deptId, @grId, @userId, @archiveId, GETDATE(), @userId, @archiveId, @buyCustNo, BUY_CUST_NAME+'(测试)' BUY_CUST_NAME, BUY_CUST_SEX, 
			BUY_CUST_AGE, BUY_CUST_CAREER, CELL_PHONE, ID_CARD, null, 1, BUY_GOAL, BUY_LENGTH, BUY_ABILITY, BUY_PAYTYPE, CUST_LEVEL, @custPlate, BUY_CUST_SOURCE, 
			BUY_CUST_LEVEL, HOUSE_ROOM, HOUSE_ROOM_1, @saleReg, @regionName, @sectionId, @sectionId, @buildId, @buildName, @saleRound, HOUSE_TYPE, HOUSE_USEAGE, HOUSE_FITMENT, 
			HOUSE_DIRECT, HOUSE_FLOOR_LOW, HOUSE_FLOOR_HIGH, HOUSE_PRICE_LOW, HOUSE_PRICE_HIGH, HOUSE_AREA_LOW, HOUSE_AREA_HIGH, HOUSE_YEAR_LOW, HOUSE_YEAR_HIGH, HOUSE_LOOK, CUST_REQUEST, 
			CUST_MEMO, BUY_CUST_STATUS, GETDATE(), REPEAT_FLAG, 0, 0, 0, 0, 0, null, null, null, null, 
			null, null, null, GETDATE(), null, 0, 0, GETDATE(), 0, null, 0, @areaId, 2
			from hft_admindb..TEMPLATE_FUN_BUY_CUSTOMER WHERE BUY_CUST_ID = @caseId
			
			insert into FUN_TRACK
			(TRACK_ID, COMP_ID, DEPT_ID, CASE_TYPE, CASE_ID, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
			TRACK_CONTENT, TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, CREATION_TIME, USEAGE, CASE_NO, TARGET_USEAGE, INDEX_SHOW, KEY_NUM, TARGET_DEPT, INCLUDE_TRACK, TRACK_RESULT) 
				select (NEXT VALUE FOR SEQ_FUN_TRACK_TRACK_ID), @compId, @deptId, CASE_TYPE, @buyCustId, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
				@userName + SUBSTRING(TRACK_CONTENT, CHARINDEX('于本日', TRACK_CONTENT, 0), LEN(TRACK_CONTENT)), TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, GETDATE(), USEAGE, @buyCustNo, null, 0, null, null, INCLUDE_TRACK, null
				FROM hft_admindb..TEMPLATE_FUN_TRACK where CASE_TYPE = 3 and CASE_ID = @caseId AND TRACK_CLASSIC = '[ 客源登记 ]'

		
		fetch next from buyCursor INTO @caseId
	end
	close buyCursor
	deallocate buyCursor



	set @userId = 0; set @buildId = 0;

	--求租客户初始化
	declare rentCursor cursor
	for select RENT_CUST_ID from HFT_ADMINDB..TEMPLATE_FUN_RENT_CUSTOMER
	OPEN rentCursor

	fetch next from rentCursor into @caseId
	while @@FETCH_STATUS = 0
	begin
		if @userCount > 1
		begin
			if @maxUserId = @userId 
				set @userId = 0
			select top 1 @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0 and USER_ID > @userId order by USER_ID
		end
		else
			select @userId = USER_ID, @userName = USER_NAME, @archiveId = ARCHIVE_ID, @grId = GR_ID from FUN_USERS where COMP_ID = @compId and DEPT_ID = @deptId and USER_WRITEOFF = 0
		
		
		if @buildCount > 0
		begin
			if @maxBuildId = @buildId
				set @buildId = 0
		
			select @buildId = A.BUILD_ID, @buildName = A.BUILD_NAME+'(测试)', @saleReg = A.BUILD_REGION, @sectionId = A.SECTION_ID, 
				@saleRound = A.BUILD_ROUND, @regionName = C.REG_NAME, @sectionName = D.SECTION_NAME from BUILDING_INFO A 
				LEFT JOIN hft_admindb..TEMPLATE_BUILDING_INFO B ON A.BUILD_ID = B.BUILD_ID AND A.CITY_ID = B.CITY_ID 
				LEFT JOIN hft_admindb..FUN_REG C ON A.BUILD_REGION = C.REG_ID
				LEFT JOIN FUN_SECTION D ON A.SECTION_ID = D.SECTION_ID
				where B.CITY_ID = @cityId and B.BUILD_ID > @buildId
		end
		else
		begin
			set @buildId = null; set @buildName = null; set @buildCode = null; set @saleReg = null; 
			set @regionName = null; set @sectionId = null; set @sectionName = null; set @saleRound = null
		end
		
		select @rentCustId = (next value for SEQ_FUN_RENT_CUSTOMER_RENT_CUST_ID)
--		exec proc_GenHouseCustNo 'FUN_RENT_CUSTOMER', @cityId, @rentCustNo output
		
		select @rentCustNo = 'QZ' + upper(COMP_NO) + substring(replace(convert(varchar(20),getdate(),112) + convert(varchar(20),getdate(),108),':',''),3,10) + 
		substring(convert(varchar(4),1000 + NEXT VALUE FOR SQ_HouseCustNo ),2,3) 
		from hft_admindb..FUN_CITY where CITY_ID = @cityId
		
		insert into FUN_RENT_CUSTOMER
			(COMP_ID, RENT_CUST_ID, CITY_ID, REG_ID, DEPT_ID, GR_ID, USER_ID, ARCHIVE_ID, CREATION_TIME, CREATOR_UID, CREATE_ARCHIVE_ID, RENT_CUST_NO, RENT_CUST_NAME, RENT_CUST_SEX, 
			RENT_CUST_AGE, RENT_CUST_CAREER, CELL_PHONE, ID_CARD, CUST_ADDR, RENT_LIFEBOUND, RENT_GOAL, RENT_LENGTH, RENT_ABILITY, RENT_PAYTYPE, CUST_LEVEL, HOUSE_ROOM, HOUSE_ROOM_1, 
			HOUSE_REGION, REGION_NAME, BUILD_ID, BUILD_NAME, SECTION_ID, SECTION_NAME, HOUSE_ROUND, HOUSE_TYPE, HOUSE_USEAGE, HOUSE_FITMENT, HOUSE_DIRECT, PLATE_TYPE, RENT_CUST_SOURCE, 
			RENT_CUST_LEVEL, HOUSE_FLOOR_LOW, HOUSE_FLOOR_HIGH, HOUSE_PRICE_LOW, HOUSE_PRICE_HIGH, HOUSE_AREA_LOW, HOUSE_AREA_HIGH, HOUSE_YEAR_LOW, HOUSE_YEAR_HIGH, HOUSE_LOOK, CUST_REQUEST, 
			CUST_MEMO, RENT_CUST_STATUS, TRACK_TIME, ACTION_TIME, REPEAT_FLAG, INFO_TYPE, SHARE_FLAG, RED_FLAG, ORANGE_FLAG, PUBLIC_COUNT, PUBLIC_TIME, DUE_TIME, SPECIAL_TIME, SCHEDULE_TIME, 
			DEAL_TIME, WRITEOFF_TIME, SECRECY_TIME, COMMEND_TIME, PRIVATE_TIME, FROM_PUBLIC, COOPERATE_FLAG, UPDATE_TIME, FRIEND_HOUSE, COOPERATE_TIME, COMPLAINT_FLAG, AREA_ID, is_ignore)
		select @compId, @rentCustId, @cityId, @regId, @deptId, @grId, @userId, @archiveId, GETDATE(), @userId, @archiveId, @rentCustNo, RENT_CUST_NAME+'(测试)' RENT_CUST_NAME, RENT_CUST_SEX, 
			RENT_CUST_AGE, RENT_CUST_CAREER,  CELL_PHONE, ID_CARD, CUST_ADDR, RENT_LIFEBOUND, RENT_GOAL, RENT_LENGTH, RENT_ABILITY, RENT_PAYTYPE, CUST_LEVEL, HOUSE_ROOM, HOUSE_ROOM_1, 
			@saleReg, @regionName, @buildId, @buildName, @sectionId, @sectionName, @saleRound, HOUSE_TYPE, HOUSE_USEAGE, HOUSE_FITMENT, HOUSE_DIRECT, @custPlate, RENT_CUST_SOURCE, 
			RENT_CUST_LEVEL, HOUSE_FLOOR_LOW, HOUSE_FLOOR_HIGH, HOUSE_PRICE_LOW, HOUSE_PRICE_HIGH, HOUSE_AREA_LOW, HOUSE_AREA_HIGH, HOUSE_YEAR_LOW, HOUSE_YEAR_HIGH, HOUSE_LOOK, CUST_REQUEST, 
			CUST_MEMO, RENT_CUST_STATUS, GETDATE(), GETDATE(), REPEAT_FLAG, 0, 0, 0, 0, 0, null, null, null, null, 
			null, null, null, null, null, 0, 0, GETDATE(), 0, null, 0, @areaId, 2 
			from hft_admindb..TEMPLATE_FUN_RENT_CUSTOMER WHERE RENT_CUST_ID = @caseId
			
		insert into FUN_TRACK
			(TRACK_ID, COMP_ID, DEPT_ID, CASE_TYPE, CASE_ID, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
			TRACK_CONTENT, TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, CREATION_TIME, USEAGE, CASE_NO, TARGET_USEAGE, INDEX_SHOW, KEY_NUM, TARGET_DEPT, INCLUDE_TRACK, TRACK_RESULT) 
		select (NEXT VALUE FOR SEQ_FUN_TRACK_TRACK_ID), @compId, @deptId, CASE_TYPE, @rentCustId, CASE_STATUS, TRACK_TYPE, TRACK_CLASSIC, TARGET_ID, TARGET_NO, TARGET_TYPE, TARGET_BOUND, TARGET_FLAG, EXAMIN_TIME, TRACK_NO, 
			@userName + SUBSTRING(TRACK_CONTENT, CHARINDEX('于本日', TRACK_CONTENT, 0), LEN(TRACK_CONTENT)), TRACK_WARM, WARM_TIME, WARM_CONTENT, TRACK_KEY, CREATOR_UID, GETDATE(), USEAGE, @rentCustNo, null, 0, null, null, INCLUDE_TRACK, null
			FROM hft_admindb..TEMPLATE_FUN_TRACK where CASE_TYPE = 4 and CASE_ID = @caseId AND TRACK_CLASSIC = '[ 客源登记 ]'

		
		fetch next from rentCursor INTO @caseId
	end
	close rentCursor
	deallocate rentCursor
	
	--设置admin库的导入标记
	update hft_admindb..FUN_DEPTS set TRYDATA_IMPORTED = 1 where COMP_NO = @compNo and DEPT_NO = @deptNo

	select 'OK' as result
END



go

