CREATE PROC [dbo].[ALTERUser]
As
Begin
DECLARE  @userId INTEGER
DECLARE  @userNUM INTEGER
DECLARE  @compId INTEGER
DECLARE  compCursor CURSOR SCROLL FOR select COMP_ID FROM FUN_COMP
open compCursor
FETCH NEXT FROM compCursor INTO @compId; --读取第一行数据(将MemberAccount表中的UserId放到@UserId变量中)
WHILE @@FETCH_STATUS = 0
BEGIN
PRINT @compId
FETCH NEXT FROM compCursor INTO @compId;
END
CLOSE compCursor
DEALLOCATE compCursor
End

go

