CREATE procedure [dbo].[proc_CreateComp]
@soft_type int,			--软件版本（1：企业版 2：专业版 3:赢销版）
@compId int,			--公司ID
@deptId int,			--门店ID
@archiveId int ,		--总经理档案号
@province_id int,		--所在省份ID
@city_id int,			--所在县市ID
@reg_id int,			--所在行政区
@compNo varchar(10),	--公司编号
@deptNo varchar(10),	--门店编号
@compName varchar(100),	--公司名称
@compCname varchar(100),--公司简称
@contact varchar(100),	--店主姓名
@deptName varchar(100),	--门店名称
@deptTele varchar(100),	--门店电话
@address varchar(100),	--公司地址
@installpwd1 varchar(40), --加密前的安装密码(明文)
@installpwd2 varchar(40), --加密后的安装密码(MD5)
@compTele varchar(15)     --公司网店域名
AS
BEGIN
declare @userId int		--总经理USER_ID
declare @region_id int  --门店服务片区
SELECT @userId = USER_ID FROM FUN_USERS WHERE ARCHIVE_ID = @archiveId AND USER_WRITEOFF = 0 and USER_EDITION = 2
SELECT @region_id = NEXT VALUE FOR SEQ_FUN_REGION_REG_ID
BEGIN TRAN
INSERT INTO FUN_COMP ( CITY_ID,COMP_ID, COMP_NO, COMP_NAME, COMP_CNAME,COMP_ADDR, COMP_TELE, COMP_CONTACT, PLAINT_PWD,INSTALL_PWD,REGIST_FLAG,COMP_TYPE,PLOT_SWITCH,STORE_NO,UPDATE_TIME )
VALUES ( @city_id,@compId,@compNo,@compName,@compCname,@address,@deptTele,@contact,@installpwd1,@installpwd2,0,@soft_type,0,@compTele,GETDATE())
if @@error <> 0 goto endline
SELECT @region_id = NEXT VALUE FOR SEQ_FUN_REGION_REG_ID
INSERT INTO FUN_DEPTS ( DEPT_ID, COMP_ID, REG_ID, DEPT_NO, COMP_NO, DEPT_NAME, SEQ_NO, DEPT_ADDR, DEPT_TELE, DEPT_CONTACT, DEPT_DESC, UPDATE_TIME, REGION_ID,DEPT_FLAG)
VALUES (@deptId,@compId,@region_id,@deptNo,@compNo,@deptName,1,@address,@deptTele,@contact,@deptName,GETDATE(), @reg_id,1)
if @@error <> 0 goto endline
INSERT INTO FUN_REGION ( REG_ID, COMP_ID, REG_NAME,SEQ_NO, ADMIN_USER,REG_ADMIN, REG_TELE, REG_DESC, UPDATE_UID, UPDATE_TIME )
VALUES ( @region_id,@compId,'市区', 1,@userid,@contact, NULL, '市区', NULL,GETDATE())
if @@error <> 0 goto endline
UPDATE FUN_USERS SET COMP_ID = @compId,DEPT_ID = @DeptId WHERE USER_ID = @userid
if @@error <> 0 goto endline
INSERT USER_ROLES VALUES(@userId,'GENERAL_MANAGER')
if @@error <> 0 goto endline
IF @soft_type = 1
INSERT USER_OPERS SELECT @userId,OPER_ID FROM ROLE_OPERS 	WHERE ROLE_ID = 'GENERAL_MANAGER'
ELSE IF @soft_type = 2
INSERT USER_OPERS SELECT @userId,OPER_ID FROM ROLE_OPERS 	WHERE ROLE_ID = 'GENERAL_MANAGER' AND PRO_ROLE = 1
ELSE IF @soft_type = 3
INSERT USER_OPERS SELECT @userId,OPER_ID FROM ROLE_OPERS 	WHERE ROLE_ID = 'GENERAL_MANAGER' AND SMP_ROLE = 1
if @@error <> 0 goto endline
INSERT SYS_PARA(COMP_ID,PARAM_ID,PARAM_VALUE,PARAM_TYPE,DEFAULT_VALUE)
SELECT @compId,PARAM_ID,PARAM_VALUE,PARAM_TYPE,DEFAULT_VALUE
FROM SYS_PARA where COMP_ID = 0
IF @soft_type = 2 or @soft_type = 3
UPDATE SYS_PARA
SET PARAM_VALUE = 0, DEFAULT_VALUE = 0
WHERE (PARAM_ID = 'BACK_PUBLIC_CANCEL' or PARAM_ID = 'ALLOW_INPUT_PHONE' ) and COMP_ID = @compId
if @@error <> 0 goto endline
UPDATE SYS_PARA SET PARAM_VALUE = @province_id,DEFAULT_VALUE= @province_id	WHERE COMP_ID = @compId AND PARAM_ID = 'FUN_PROVINCE'
if @@error <> 0 goto endline
UPDATE SYS_PARA SET PARAM_VALUE = @city_id,DEFAULT_VALUE= @city_id	WHERE COMP_ID = @compId AND PARAM_ID = 'FUN_CITY'
if @@error <> 0 goto endline
UPDATE SYS_PARA SET PARAM_VALUE = @compNo,DEFAULT_VALUE= @compNo WHERE COMP_ID = @compId AND PARAM_ID = 'COMP_NO'
if @@error <> 0 goto endline
UPDATE SYS_PARA SET PARAM_VALUE = @compName,DEFAULT_VALUE= @compName WHERE COMP_ID = @compId AND PARAM_ID = 'COMP_NAME'
if @@error <> 0 goto endline
UPDATE SYS_PARA SET PARAM_VALUE = @deptName,DEFAULT_VALUE= @deptName WHERE COMP_ID = @compId AND PARAM_ID = 'DEPT_NAME'
if @@error <> 0 goto endline
UPDATE SYS_PARA SET PARAM_VALUE = @deptNo,DEFAULT_VALUE= @deptNo WHERE COMP_ID = @compId AND PARAM_ID = 'DEPT_NO'
if @@error <> 0 goto endline
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(1,@compId,'服务质量',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(2,@compId,'合作精神',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(3,@compId,'创新精神',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(4,@compId,'精神面貌',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(5,@compId,'工作效率',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(6,@compId,'沟通能力',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(7,@compId,'专业知识',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(8,@compId,'专业技能',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(9,@compId,'工作能力',10)
INSERT FUN_EVAL_ST(ST_ID,COMP_ID,ST_NAME,ST_SCORE) VALUES(10,@compId,'团队精神',10)
endline:
IF @@error = 0
BEGIN
COMMIT TRAN
SELECT @compNo + '|' + @deptNo as result
return
END
ELSE
BEGIN
ROLLBACK TRAN
SELECT 'ERROR' as result
return
END
END

go

