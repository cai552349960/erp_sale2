create procedure [dbo].[SP_WHO_LOCK2]
AS
BEGIN
set nocount on
declare @sql nvarchar(1000),@blk int,@blk1 int,@blk_b int ,@lock_path varchar(1000)
create table #tmp(spid int,ecid int,status varchar(20),loginname varchar(100),hostname varchar(100),blk int,dbname varchar(50),cmd varchar(100),request_id int)
declare @lock_table table(lockpath  varchar(200),blk int)
set @sql = 'sp_who'
set @lock_path = ''
insert into #tmp
exec sp_executesql @sql
declare c1 cursor for
select distinct blk from #tmp where blk > 0
open c1
fetch c1 into @blk
while @@FETCH_STATUS = 0
begin
set @blk_b = @blk
set @lock_path = '锁链：'+convert(varchar(10),@blk)+' <= '
select @blk1=blk from #tmp where spid = @blk
while @blk1 > 0 and @blk1 <> @blk
begin
set @lock_path =@lock_path + convert(varchar(10),@blk1)+' <= '
set @blk = @blk1
select @blk1=blk from #tmp where spid = @blk
end
if @blk_b <> @blk
begin
set @lock_path =@lock_path + convert(varchar(10),@blk)+' 。'
insert @lock_table values(@lock_path,@blk)
end
fetch c1 into @blk
end
close c1
deallocate c1
if (select COUNT(1) from @lock_table) = 0
select '当前无阻塞链进程'
else
begin
SELECT lockpath as '锁链列表' from @lock_table order by LEN(lockpath) desc
SELECT * FROM #TMP WHERE SPID in(select blk from @lock_table) order by spid
declare c2 cursor for
select distinct blk from @lock_table order by blk
open c2
fetch c2 into @blk
while @@FETCH_STATUS = 0
begin
dbcc inputbuffer(@blk)
fetch c2 into @blk
end
close c2
deallocate c2
end
drop table #tmp
END

go

