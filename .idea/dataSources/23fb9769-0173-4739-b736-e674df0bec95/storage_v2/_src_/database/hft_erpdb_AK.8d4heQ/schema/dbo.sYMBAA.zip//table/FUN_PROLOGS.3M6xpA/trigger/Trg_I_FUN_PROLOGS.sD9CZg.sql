

-- =============================================
-- Author:    <Author,,方李骥>
-- Create date: <Create Date,2017-07-14>
-- Description:  <Description,记录历史跟进表更新记录，为方便到mongo>
-- =============================================
CREATE TRIGGER [dbo].[Trg_I_FUN_PROLOGS]
   ON  [dbo].[FUN_PROLOGS]
   AFTER INSERT
AS 
BEGIN

  SET NOCOUNT ON;

    INSERT hft_admindb..TRACKTEMPLOG_SYSINFO([DB_NAME],TABLE_NAME,CASE_ID,DEAL_TYPE,CREATION_TIME)
  SELECT 'hft_erpdb_AK','FUN_PROLOGS',ID,1 AS DEAL_TYPE,GETDATE() FROM INSERTED

END
go

