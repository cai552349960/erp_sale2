CREATE PROCEDURE [dbo].[proc_BuildSingleCount]
@bulid_id VARCHAR(60),--楼盘ID或者楼盘名称模糊匹配
@caseType VARCHAR(10),--出售或者出租
@startTime VARCHAR(20),--开始时间
@endTime  VARCHAR(20),--结束时间
@con VARCHAR(500)  --筛选单价超过一定限制的不合格数据 (一个条件SQL语句) 例:用途为 住宅时:单价不能超过2万/平米 (不用再加AND) 包括:用途,单价条件
AS
BEGIN
SET NOCOUNT ON;
CREATE TABLE #tmp_A (
SUM_V INT NULL,
AVG_V FLOAT NULL,
FLAG  VARCHAR(10) NULL,
ROOMS VARCHAR(2) NULL
)
CREATE TABLE #TMP_B(
STREET INT NULL,
PRICE FLOAT NULL,
FITMENT VARCHAR(30) NULL,
AREA INT,
HOUSE_FLOOR INT,
ROOM INT NULL
)
CREATE TABLE #TMP_B1(
STREET INT NULL,
PRICE FLOAT NULL,
FITMENT VARCHAR(30) NULL,
AREA INT,
HOUSE_FLOOR INT,
ROOM INT NULL
)
DECLARE
@SqlStr1        NVARCHAR(500),
@SqlStr2        NVARCHAR(500),
@SqlStr3        NVARCHAR(500),
@SqlStr4        NVARCHAR(500),
@SqlStr5        NVARCHAR(500),
@SqlStr6        NVARCHAR(500),
@sqlStrAddUp	NVARCHAR(300),
@queryField     VARCHAR(100),
@conditionB     VARCHAR(10),
@conditionC     VARCHAR(10),
@roomCondition  VARCHAR(100),
@dateCondition  VARCHAR(100),
@roomInt INT = 1,
@count INT = 0, --用于判断是否已经有了统计记录
@sumV INT,
@avgV FLOAT,
@flag VARCHAR(10),
@rooms VARCHAR(2),
@tmpSql1 NVARCHAR(500),
@type VARCHAR(100)
IF @caseType = '1'
BEGIN
SET @type = 'CASE_TYPE IN (''1'',''5'')'
END
ELSE IF @caseType = '2'
BEGIN
SET @type = 'CASE_TYPE IN (''2'',''6'')'
END
ELSE
BEGIN
SET @type = 'CASE_TYPE = '''+@caseType+''''
END;
SET @queryField = '@sumV = CONVERT(INT,ISNULL(COUNT(''X''),0)),@avgV = CONVERT(FLOAT,ISNULL(AVG(PRICE), 0))'
SET @dateCondition = ' CREATE_DATE BETWEEN '''+@startTime+''' AND '''+@endTime+' 23:59:59'''
SET @tmpSql1 = 'INSERT INTO #TMP_B1(STREET,PRICE,FITMENT,AREA,HOUSE_FLOOR,ROOM) SELECT STREET,PRICE,FITMENT,FLOOR(AREA),null,ROOM FROM FUN_ALL_COUNTDATA WHERE ' + @con + ' AND '+@dateCondition + ' AND '+ @bulid_id + ' AND ' + @type;
EXEC sp_executesql @tmpSql1
INSERT INTO #TMP_B(PRICE,AREA,ROOM,FITMENT,HOUSE_FLOOR,STREET) SELECT AVG(PRICE),AREA,ROOM,FITMENT,HOUSE_FLOOR,STREET FROM #TMP_B1 GROUP BY AREA,ROOM,FITMENT,HOUSE_FLOOR,STREET
WHILE @roomInt <= 4
BEGIN
IF CAST(@roomInt AS INT) <= 3
BEGIN
IF CAST(@roomInt AS INT) = 1
BEGIN
SET @roomCondition = ' AND ROOM >= ' + convert(varchar(1),(CAST(@roomInt AS INT)-1))  + ' AND ROOM <=' + convert(varchar(2),@roomInt)
END
ELSE
BEGIN
SET @roomCondition = ' AND ROOM = '  + convert(varchar(2),@roomInt)
END
END
ELSE
BEGIN
SET @roomCondition = ' AND ROOM > 3'
END
SET @SqlStr1 = 'SELECT '+@queryField+' ,@flag = ''ALL'',@rooms = ' + convert(varchar(2),@roomInt) + ' FROM #TMP_B WHERE 1=1 ' + @roomCondition;
EXEC sp_executesql @sqlStr1,N'@sumV INT OUTPUT,@avgV FLOAT OUTPUT,@flag VARCHAR(10) OUTPUT,@rooms VARCHAR(2) OUTPUT',@sumV output,@avgV output,@flag output,@rooms output;
SELECT @count = COUNT(*) FROM #tmp_A WHERE FLAG = @flag AND ROOMS = @rooms;
IF @count = 0
BEGIN
SET @sqlStrAddUp = 'INSERT INTO #tmp_A(SUM_V,AVG_V,FLAG,ROOMS)VALUES('+CONVERT(VARCHAR(10),@sumV)+','+CONVERT(VARCHAR(10),@avgV)+','''+@flag+''','''+@rooms+''')';
END
ELSE
BEGIN
SET @sqlStrAddUp = 'UPDATE #tmp_A SET SUM_V = SUM_V + ' + CONVERT(VARCHAR(10),@sumV) + ',AVG_V = ' + CONVERT(VARCHAR(10),@avgV) + ' WHERE FLAG = ''' + @flag + ''' AND ROOMS = ''' + @rooms + '''';
END
EXEC sp_executesql @sqlStrAddUp;
SET @SqlStr2 = 'SELECT '+@queryField+' ,@flag = ''STREET'',@rooms = ' + convert(varchar(2),@roomInt) + ' FROM #TMP_B WHERE STREET = 1 ' + @roomCondition;
EXEC sp_executesql @sqlStr2,N'@sumV INT OUTPUT,@avgV FLOAT OUTPUT,@flag VARCHAR(10) OUTPUT,@rooms VARCHAR(2) OUTPUT',@sumV output,@avgV output,@flag output,@rooms output;
SELECT @count = COUNT(*) FROM #tmp_A WHERE FLAG = @flag AND ROOMS = @rooms;
IF @count = 0
BEGIN
SET @sqlStrAddUp = 'INSERT INTO #tmp_A(SUM_V,AVG_V,FLAG,ROOMS)VALUES('+CONVERT(VARCHAR(10),@sumV)+','+CONVERT(VARCHAR(10),@avgV)+','''+@flag+''','''+@rooms+''')';
END
ELSE
BEGIN
SET @sqlStrAddUp = 'UPDATE #tmp_A SET SUM_V = SUM_V + ' + CONVERT(VARCHAR(10),@sumV) + ',AVG_V = ' + CONVERT(VARCHAR(10),@avgV) + ' WHERE FLAG = ''' + @flag + ''' AND ROOMS = ''' + @rooms + '''';
END
EXEC sp_executesql @sqlStrAddUp;
SET @SqlStr3 = 'SELECT '+@queryField+' ,@flag = ''NOFITMENT'',@rooms = ' + convert(varchar(2),@roomInt) + ' FROM #TMP_B WHERE FITMENT = ''NOFITMENT''' + @roomCondition;
EXEC sp_executesql @sqlStr3,N'@sumV INT OUTPUT,@avgV FLOAT OUTPUT,@flag VARCHAR(10) OUTPUT,@rooms VARCHAR(2) OUTPUT',@sumV output,@avgV output,@flag output,@rooms output;
SELECT @count = COUNT(*) FROM #tmp_A WHERE FLAG = @flag AND ROOMS = @rooms;
IF @count = 0
BEGIN
SET @sqlStrAddUp = 'INSERT INTO #tmp_A(SUM_V,AVG_V,FLAG,ROOMS)VALUES('+CONVERT(VARCHAR(10),@sumV)+','+CONVERT(VARCHAR(10),@avgV)+','''+@flag+''','''+@rooms+''')';
END
ELSE
BEGIN
SET @sqlStrAddUp = 'UPDATE #tmp_A SET SUM_V = SUM_V + ' + CONVERT(VARCHAR(10),@sumV) + ',AVG_V = ' + CONVERT(VARCHAR(10),@avgV) + ' WHERE FLAG = ''' + @flag + ''' AND ROOMS = ''' + @rooms + '''';
END
EXEC sp_executesql @sqlStrAddUp;
SET @SqlStr4 = 'SELECT '+@queryField+' ,@flag = ''COMMON'',@rooms = ' + convert(varchar(2),@roomInt) + ' FROM #TMP_B WHERE FITMENT = ''COMMON''' + @roomCondition;
EXEC sp_executesql @sqlStr4,N'@sumV INT OUTPUT,@avgV FLOAT OUTPUT,@flag VARCHAR(10) OUTPUT,@rooms VARCHAR(2) OUTPUT',@sumV output,@avgV output,@flag output,@rooms output;
SELECT @count = COUNT(*) FROM #tmp_A WHERE FLAG = @flag AND ROOMS = @rooms;
IF @count = 0
BEGIN
SET @sqlStrAddUp = 'INSERT INTO #tmp_A(SUM_V,AVG_V,FLAG,ROOMS)VALUES('+CONVERT(VARCHAR(10),@sumV)+','+CONVERT(VARCHAR(10),@avgV)+','''+@flag+''','''+@rooms+''')';
END
ELSE
BEGIN
SET @sqlStrAddUp = 'UPDATE #tmp_A SET SUM_V = SUM_V + ' + CONVERT(VARCHAR(10),@sumV) + ',AVG_V = ' + CONVERT(VARCHAR(10),@avgV) + ' WHERE FLAG = ''' + @flag + ''' AND ROOMS = ''' + @rooms + '''';
END
EXEC sp_executesql @sqlStrAddUp;
SET @SqlStr5 = 'SELECT '+@queryField+' ,@flag = ''PERFECT'',@rooms = ' + convert(varchar(2),@roomInt) + ' FROM #TMP_B WHERE FITMENT IN (''PERFECT'',''QUALITY'')' + @roomCondition;
EXEC sp_executesql @sqlStr5,N'@sumV INT OUTPUT,@avgV FLOAT OUTPUT,@flag VARCHAR(10) OUTPUT,@rooms VARCHAR(2) OUTPUT',@sumV output,@avgV output,@flag output,@rooms output;
SELECT @count = COUNT(*) FROM #tmp_A WHERE FLAG = @flag AND ROOMS = @rooms;
IF @count = 0
BEGIN
SET @sqlStrAddUp = 'INSERT INTO #tmp_A(SUM_V,AVG_V,FLAG,ROOMS)VALUES('+CONVERT(VARCHAR(10),@sumV)+','+CONVERT(VARCHAR(10),@avgV)+','''+@flag+''','''+@rooms+''')';
END
ELSE
BEGIN
SET @sqlStrAddUp = 'UPDATE #tmp_A SET SUM_V = SUM_V + ' + CONVERT(VARCHAR(10),@sumV) + ',AVG_V = ' + CONVERT(VARCHAR(10),@avgV) + ' WHERE FLAG = ''' + @flag + ''' AND ROOMS = ''' + @rooms + '''';
END
EXEC sp_executesql @sqlStrAddUp;
SET @SqlStr6 = 'SELECT '+@queryField+' ,@flag = ''DELUXE'',@rooms = ' + convert(varchar(2),@roomInt) + ' FROM #TMP_B WHERE FITMENT = ''DELUXE''' + @roomCondition;
EXEC sp_executesql @sqlStr6,N'@sumV INT OUTPUT,@avgV FLOAT OUTPUT,@flag VARCHAR(10) OUTPUT,@rooms VARCHAR(2) OUTPUT',@sumV output,@avgV output,@flag output,@rooms output;
SELECT @count = COUNT(*) FROM #tmp_A WHERE FLAG = @flag AND ROOMS = @rooms;
IF @count = 0
BEGIN
SET @sqlStrAddUp = 'INSERT INTO #tmp_A(SUM_V,AVG_V,FLAG,ROOMS)VALUES('+CONVERT(VARCHAR(10),@sumV)+','+CONVERT(VARCHAR(10),@avgV)+','''+@flag+''','''+@rooms+''')';
END
ELSE
BEGIN
SET @sqlStrAddUp = 'UPDATE #tmp_A SET SUM_V = SUM_V + ' + CONVERT(VARCHAR(10),@sumV) + ',AVG_V = ' + CONVERT(VARCHAR(10),@avgV) + ' WHERE FLAG = ''' + @flag + ''' AND ROOMS = ''' + @rooms + '''';
END
EXEC sp_executesql @sqlStrAddUp;
SET @roomInt = @roomInt + 1
END
SELECT * FROM #tmp_A ORDER BY FLAG , ROOMS
DROP TABLE #tmp_A;
DROP TABLE #TMP_B1;
DROP TABLE #TMP_B;
END

go

