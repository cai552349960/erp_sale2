CREATE PROCEDURE [dbo].[proc_ProcessComplain]
@connId VARCHAR(30),--数据库连接ID
@CC_USER_ID VARCHAR(30), --投诉人ID
@DEF_USER_ID VARCHAR(30), --被投诉人ID
@CASE_NO VARCHAR(50),--投诉房源编号
@RESULT INT,--处理结果
@CASE_TYPE VARCHAR(30),--类型
@ccTime VARCHAR(30),--投诉时间
@hortationAdd VARCHAR(5), --投诉成功后奖励条数
@hortationSub VARCHAR(5), --投诉成功后奖励条数
@addComp VARCHAR(5),--是否累积被投诉次数
@useAge int
AS
DECLARE @compId INT,
@deptId INT,
@userId INT,
@userIdIsExist INT,
@taskStr VARCHAR(300),
@sql NVARCHAR(2000),
@dateTime VARCHAR(30),
@cnCaseType VARCHAR(10),
@taskId INT,
@tableName VARCHAR(20),
@columnName VARCHAR(10),
@columnName2 VARCHAR(20)
BEGIN
SET NOCOUNT ON;
SET @sql = 'SELECT @compId = COMP_ID,@deptId = DEPT_ID,@userId = USER_ID FROM FUN_USERS WHERE USER_ID = ''' + @CC_USER_ID + '''';
EXEC SP_EXECUTESQL @sql,N'@compId INT OUTPUT,@deptId INT OUTPUT,@userId INT OUTPUT',@compId OUTPUT,@deptId OUTPUT,@userId OUTPUT;
IF @CASE_TYPE = '1'
BEGIN
SET @cnCaseType = '出售';
SET @tableName = 'FUN_SALE_HOUSING';
SET	@columnName = 'SALE_NO';
SET @columnName2 = 'SALE_COOPERATE';
IF @useAge = '3' SET @tableName = 'FUN_SALE_TRADE';
IF @useAge = '4' SET @tableName = 'FUN_SALE_OFFICE';
END
ELSE IF @CASE_TYPE = '2'
BEGIN
SET @cnCaseType = '出租';
SET @tableName = 'FUN_LEASE_HOUSING';
SET	@columnName = 'LEASE_NO';
SET @columnName2 = 'LEASE_COOPERATE';
IF @useAge = '3' SET @tableName = 'FUN_LEASE_TRADE';
IF @useAge = '4' SET @tableName = 'FUN_LEASE_OFFICE';
END
SET @dateTime = @ccTime;
IF @RESULT = 1
BEGIN
SET @taskStr = '你于'+@dateTime+'对'+@CASE_NO+'的'+@cnCaseType+'房源的投诉已被成功受理,系统已为你增加 ' + @hortationAdd + ' 条合作信息查看权.';
END
ELSE IF @RESULT = 2
BEGIN
SET @taskStr = '你于'+@dateTime+'对'+@CASE_NO+'的'+@cnCaseType+'房源的投诉经好房通ERP系统后台审查,认为投诉理由不够充分予以撤消投诉. <br />感谢你对好房通联网平台的支持!';
END
SET @sql = 'SELECT @taskId = ISNULL(MAX(TASK_ID),0) + 1 FROM FUN_TASK';
EXEC SP_EXECUTESQL @sql,N'@taskId INT OUTPUT',@taskId OUTPUT;
BEGIN TRANSACTION
SET @sql = 'INSERT INTO FUN_TASK (TASK_ID,CASE_ID,WARM_TIME,CASE_NO,CASE_TYPE,IS_READ,DEPT_ID,COMP_ID,TASK_TYPE,TASK_OWNER,TRACK_WARM,TASK_STATUS,CREATOR_UID,CREATION_TIME,TASK_SUBJECT,TASK_DESC,USEAGE,TYPE_FLAG)
VALUES('+CONVERT(VARCHAR(10),@taskId)+','''','''+CONVERT(VARCHAR(30),GETDATE())+''','''+@CASE_NO+''','''+@CASE_TYPE+''',0,'+CONVERT(VARCHAR(10),@deptId)+','+CONVERT(VARCHAR(10),@compId)+',''3'','+CONVERT(VARCHAR(10),@userId)+',1,''1'',999,'''+CONVERT(VARCHAR(30),GETDATE())+''',''[ 提醒任务 ] 请查看投诉处理结果!'','''+@taskStr+''','+CONVERT(varchar(10),@useAge)+',0)';
EXEC SP_EXECUTESQL @sql
IF(@@ERROR<>0)
BEGIN
ROLLBACK TRANSACTION
RAISERROR('存储过程生成投诉提醒任务时出错!',15,1)
RETURN;
END
SET @sql = 'SELECT @compId = COMP_ID,@deptId = DEPT_ID,@userId = USER_ID FROM FUN_USERS WHERE USER_ID = ''' + @DEF_USER_ID + '''';
EXEC SP_EXECUTESQL @sql,N'@compId INT OUTPUT,@deptId INT OUTPUT,@userId INT OUTPUT',@compId OUTPUT,@deptId OUTPUT,@userId OUTPUT;
IF @RESULT = 1
BEGIN
IF @addComp = 'on' OR @addComp = 'ON'
BEGIN
SET @taskStr = @dateTime + '对你编号为'+@CASE_NO+'的'+@cnCaseType+'房源的投诉经好房通ERP系统后台审查予以确认,系统已扣除你 '+@hortationSub+' 条合作信息查看量.由于您已经对信息进行了下架处理,所以没有累计被投诉次数.';
END
ELSE
BEGIN
SET @taskStr = @dateTime + '对你编号为'+@CASE_NO+'的'+@cnCaseType+'房源的投诉经好房通ERP系统后台审查予以确认,系统已扣除你 '+@hortationSub+' 条合作信息查看量.';
END
SET @sql = 'SELECT @userIdIsExist = ISNULL(USER_ID,0) FROM ' + @tableName + ' WHERE ' + @columnName + '='''+@CASE_NO+'''';
EXEC SP_EXECUTESQL @sql,N'@userIdIsExist INT OUTPUT',@userIdIsExist OUTPUT;
END
ELSE IF @RESULT = 2
BEGIN
SET @taskStr = @dateTime + '对你编号为'+@CASE_NO+'的'+@cnCaseType+'房源的投诉经好房通ERP系统后台审查,认为投诉理由不够充分予以撤消投诉.';
END
IF @userIdIsExist > 0
BEGIN
SET @sql = 'SELECT @taskId = ISNULL(MAX(TASK_ID),0) + 1 FROM FUN_TASK';
EXEC SP_EXECUTESQL @sql,N'@taskId INT OUTPUT',@taskId OUTPUT;
SET @sql = 'INSERT INTO FUN_TASK (TASK_ID,CASE_ID,WARM_TIME,CASE_NO,CASE_TYPE,IS_READ,DEPT_ID,COMP_ID,TASK_TYPE,TASK_OWNER,TRACK_WARM,TASK_STATUS,CREATOR_UID,CREATION_TIME,TASK_SUBJECT,TASK_DESC,USEAGE,TYPE_FLAG)
VALUES('+CONVERT(VARCHAR(10),@taskId)+','''','''+CONVERT(VARCHAR(30),GETDATE())+''','''+@CASE_NO+''','''+@CASE_TYPE+''',0,'+CONVERT(VARCHAR(10),@deptId)+','+CONVERT(VARCHAR(10),@compId)+',''3'','+CONVERT(VARCHAR(10),@userId)+',1,''1'',999,'''+CONVERT(VARCHAR(30),GETDATE())+''',''[ 提醒任务 ] 请查看投诉处理结果!'','''+@taskStr+''','+CONVERT(varchar(10),@useAge)+',0)';
EXEC SP_EXECUTESQL @sql
IF(@@ERROR<>0)
BEGIN
ROLLBACK TRANSACTION
RAISERROR('存储过程生成投诉提醒任务时出错!',15,1)
RETURN;
END
SET @sql = 'UPDATE ' + @tableName + ' SET '+@columnName2+' = 0,COMPLAINT_FLAG = 1 WHERE ' + @columnName + '='''+@CASE_NO+'''';
EXEC SP_EXECUTESQL @sql
IF(@@ERROR<>0)
BEGIN
ROLLBACK TRANSACTION
RAISERROR('存储过程更新房源投诉标记和不合作标记时出错!',15,1)
RETURN;
END
SET @sql = 'UPDATE ' + @tableName + ' SET '+@columnName2+' = 0,COMPLAINT_FLAG = 1 WHERE ' + @columnName + '='''+@CASE_NO+'''';
EXEC SP_EXECUTESQL @sql
IF(@@ERROR<>0)
BEGIN
ROLLBACK TRANSACTION
RAISERROR('存储过程更新房源投诉标记和不合作标记时出错!',15,1)
RETURN;
END
END
COMMIT TRANSACTION
END

go

