CREATE FUNCTION [dbo].[getFirstStr]
(
@param1 VARCHAR(30),--分割符
@param2 VARCHAR(8000)--需要分割的字符串
)
RETURNS VARCHAR(30)
AS
BEGIN
DECLARE @T INT, @tmp varchar(30)
SET @T = charindex(@param1,ltrim(rtrim(@param2)));
IF @T > 0
BEGIN
SET @tmp = left(ltrim(rtrim(@param2)),@T);
END
ELSE
BEGIN
SET @tmp = @param2;
END
RETURN ltrim(rtrim(@tmp))
END

go

