CREATE procedure [dbo].[proc_SplitPage]
@SelectSql varchar(2000),		--表名 ( SELECT COLUMN1,... FROM.TABLE1,... WHERE ...)
@OrderByColumn varchar(200),    --排序字段（Table1.Column1,Table2.Column2,...）
@PageNo int,					--返回第几页
@PageSize int					--每页行数
AS

BEGIN

  DECLARE @SqlStr nvarchar(3500),@StartNum varchar(50),@CountNum int

  SET @StartNum = ( @PageNo - 1 ) * @PageSize 

  SET @SqlStr = @SelectSql + ' 
		 Order By ' + @OrderByColumn + '  
		 Offset ' + convert(varchar(10),@StartNum) + ' Rows 
		 Fetch Next '+ convert(varchar(10),@PageSize) + 'Rows Only';
  
  EXEC Sp_executesql @SqlStr;

END
go

