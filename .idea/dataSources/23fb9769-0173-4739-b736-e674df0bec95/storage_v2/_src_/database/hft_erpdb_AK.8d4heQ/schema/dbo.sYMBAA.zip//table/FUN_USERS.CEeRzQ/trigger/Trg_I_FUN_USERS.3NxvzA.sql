
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,用于更新经纪人姓名的首拼检索码>
-- =============================================
CREATE TRIGGER Trg_I_FUN_USERS
   ON  FUN_USERS
   AFTER INSERT
AS 
BEGIN
	
	SET NOCOUNT ON;

	UPDATE A SET A.USER_CODE = SUBSTRING(hft_admindb.dbo.fun_getPY(I.USER_NAME),1,10)
	FROM FUN_USERS A,INSERTED I
	WHERE A.USER_ID = I.USER_ID

END


go

