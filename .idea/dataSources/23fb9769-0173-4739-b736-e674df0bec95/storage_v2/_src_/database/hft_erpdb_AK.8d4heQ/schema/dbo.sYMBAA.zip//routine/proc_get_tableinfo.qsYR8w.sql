CREATE PROCEDURE [dbo].[proc_get_tableinfo] AS
BEGIN
	set nocount on
	if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tablespaceinfo]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
		create table tablespaceinfo --创建结果存储表
		(nameinfo varchar(50) ,
		rowsinfo int , 
		reserved varchar(20),
		datainfo varchar(20),
		index_size varchar(20) ,
		unused varchar(20) )

	delete from tablespaceinfo --清空数据表
	declare @tablename varchar(255)--表名称
	declare @cmdsql nvarchar(500)
	
	DECLARE Info_cursor CURSOR FOR
		select o.name from dbo.sysobjects o where OBJECTPROPERTY(o.id, N'IsTable') = 1 and o.name not like N'#%%'order by o.name

	OPEN Info_cursor
	FETCH NEXT FROM Info_cursor INTO @tablename

	WHILE @@FETCH_STATUS = 0
	BEGIN
		if exists (select * from dbo.sysobjects where id = object_id(@tablename) and OBJECTPROPERTY(id, N'IsUserTable') = 1)
		begin
			set @cmdsql = 'insert into tablespaceinfo exec sp_spaceused ''' + @tablename + ''''
			execute sp_executesql @cmdsql
		end

		FETCH NEXT FROM Info_cursor INTO @tablename
	END

	CLOSE Info_cursor
	DEALLOCATE Info_cursor

	insert adba..tablerowsinfo(db_name,table_name,rowscount,reserved,datainfo,index_size,creation_time)
	select db_name(),nameinfo,rowsinfo,replace(reserved,' KB',''),replace(datainfo,' KB',''),replace(index_size,' KB',''),convert(varchar(20),getdate(),102) from tablespaceinfo

	drop table tablespaceinfo
END
go

