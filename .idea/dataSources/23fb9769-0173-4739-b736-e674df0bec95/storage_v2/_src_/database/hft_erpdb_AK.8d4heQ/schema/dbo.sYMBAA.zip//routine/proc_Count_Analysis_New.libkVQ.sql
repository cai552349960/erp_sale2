CREATE PROCEDURE [dbo].[proc_Count_Analysis_New]
@Indicators int,
@unit varchar(4),
@type varchar(10),
@con varchar(2000),
@user_id varchar(30),
@rq1 datetime,
@rq2 datetime
AS
BEGIN
SET NOCOUNT ON;
CREATE TABLE #tmp_rtn(
datatype INT null,
create_num FLOAT null,
creation_day INT null)
DECLARE  @sql1 NVARCHAR(1000),
@sql2 NVARCHAR(1000),
@sql3 NVARCHAR(1000),
@sql4 NVARCHAR(1000),
@sql5 NVARCHAR(1000),
@sql6 NVARCHAR(1000),
@deptId INT,
@userId INT,
@userdb VARCHAR(20),
@infotable VARCHAR(500),
@comcolumn VARCHAR(50),
@comcolumn2 VARCHAR(50),
@city_id INT,
@tmp_COMPNO VARCHAR(30),
@caseType VARCHAR(100)
SELECT @city_id = city_id FROM FUN_USERS WHERE USER_ID = @user_id
SET @infotable = 'FUN_ALL_COUNTDATA'
SET @comcolumn = CASE @Indicators
when 1 then 'COUNT(*)'
when 2 then 'SUM(AREA)'
when 3 then 'AVG(TOTALPRICE)'
when 4 then 'AVG(PRICE)'
END
SET @comcolumn2 = CASE @Indicators
when 1 then 'COUNT(*)'
when 2 then 'SUM(create_num)'
when 3 then 'AVG(create_num)'
when 4 then 'AVG(create_num)'
END
IF @type = '1'
BEGIN
SET @caseType = 'CASE_TYPE IN (''1'',''5'')'
END
ELSE IF @type = '2'
BEGIN
SET @caseType = 'CASE_TYPE IN (''2'',''6'')'
END
ELSE
BEGIN
SET @caseType = 'CASE_TYPE = '''+@type+''''
END;
SET @infotable = @infotable + ' WHERE 1=1 ' + @con + ' AND CITY_ID = ' + CONVERT(VARCHAR(10),@city_id) + ' AND '+@caseType+' AND CREATE_DATE BETWEEN ''' + CONVERT(VARCHAR(30),@rq1) + ''' AND ''' + CONVERT(VARCHAR(30),@rq2) + '''';
SET @sql1 = 'INSERT INTO #tmp_rtn SELECT 1 as datatype,'+@comcolumn+' as create_num, datepart('+@unit+',CREATE_DATE) as creation_day FROM '+@infotable+' group by datepart('+@unit+',CREATE_DATE)'
EXEC SP_EXECUTESQL @sql1;
SET @sql2 = 'INSERT INTO #tmp_rtn SELECT 2 as datatype,'+@comcolumn2+' as create_num,creation_day FROM (SELECT 2 as datatype,'+@comcolumn+' as create_num, datepart('+@unit+',CREATE_DATE) as creation_day FROM '+@infotable+' group by DEPT_ID,datepart('+@unit+',CREATE_DATE)) AS TMP_T group by creation_day'
EXEC SP_EXECUTESQL @sql2;
SET @sql3 = 'INSERT INTO #tmp_rtn SELECT 3 as datatype,'+@comcolumn+' as create_num, datepart('+@unit+',CREATE_DATE) as creation_day FROM '+@infotable+' AND DEPT_ID = '+CONVERT(VARCHAR(30),@deptId)+' group by datepart('+@unit+',CREATE_DATE)'
EXEC SP_EXECUTESQL @sql3;
IF @Indicators = 1
BEGIN
SET @sql4 = 'INSERT INTO #tmp_rtn SELECT 4 as datatype,'+@comcolumn+'/(SELECT COUNT(*) FROM FUN_USERS WHERE USER_WRITEOFF = 0) as create_num, datepart('+@unit+',CREATE_DATE) as creation_day FROM '+@infotable+' GROUP BY datepart('+@unit+',CREATE_DATE)'
END
ELSE
BEGIN
SET @sql4 = 'INSERT INTO #tmp_rtn SELECT 4 as datatype,'+@comcolumn2+' as create_num,creation_day FROM (SELECT 4 as datatype,'+@comcolumn+' as create_num, datepart('+@unit+',CREATE_DATE) as creation_day FROM '+@infotable+' AND USER_ID IS NOT NULL GROUP BY USER_ID,datepart('+@unit+',CREATE_DATE)) AS TMP_T group by creation_day'
END
EXEC SP_EXECUTESQL @sql4;
SET @sql5 = 'INSERT INTO #tmp_rtn SELECT 5 as datatype,'+@comcolumn2+' as create_num,creation_day FROM (SELECT 5 as datatype,'+@comcolumn+' as create_num, datepart('+@unit+',CREATE_DATE) as creation_day FROM '+@infotable+' AND DEPT_ID = '+CONVERT(VARCHAR(30),@deptId)+' group by USER_ID,datepart('+@unit+',CREATE_DATE)) AS TMP_T group by creation_day'
EXEC SP_EXECUTESQL @sql5;
SET @sql6 = 'INSERT INTO #tmp_rtn SELECT 6 as datatype,'+@comcolumn+' as create_num, datepart('+@unit+',CREATE_DATE) as creation_day FROM '+@infotable+' AND USER_ID = '+CONVERT(VARCHAR(30),@userId)+' group by datepart('+@unit+',CREATE_DATE)'
EXEC SP_EXECUTESQL @sql6;
SELECT * FROM #tmp_rtn;
DROP TABLE #tmp_rtn;
END

go

