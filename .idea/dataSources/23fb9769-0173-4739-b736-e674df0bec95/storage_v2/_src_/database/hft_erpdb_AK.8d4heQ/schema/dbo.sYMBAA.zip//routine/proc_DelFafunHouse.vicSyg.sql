CREATE PROCEDURE [dbo].[proc_DelFafunHouse]
@ArchiveId int
AS
BEGIN
SET NOCOUNT ON;
DELETE c FROM fafunv2.dbo.count_done c
inner join fafunv2.dbo.shop_info s on c.s_id = s.s_id and s.archive_id = 1
left join hft_erpdb.dbo.FUN_SALE_HOUSING f on c.house_id = f.SALE_ID and f.INFO_TYPE = 0
WHERE c.sale_lease = 1 and c.house_type not in(3,4) --住宅
DELETE c FROM fafunv2.dbo.count_done c
inner join fafunv2.dbo.shop_info s on c.s_id = s.s_id and s.archive_id = 1
left join hft_erpdb.dbo.FUN_SALE_TRADE f on c.house_id = f.SALE_ID and f.INFO_TYPE = 0
WHERE c.sale_lease = 1 and c.house_type = 3 --商铺
DELETE c FROM fafunv2.dbo.count_done c
inner join fafunv2.dbo.shop_info s on c.s_id = s.s_id and s.archive_id = 1
left join hft_erpdb.dbo.FUN_SALE_OFFICE f on c.house_id = f.SALE_ID and f.INFO_TYPE = 0
WHERE c.sale_lease = 1 and c.house_type = 4  --写字楼
DELETE c FROM fafunv2.dbo.count_done c
inner join fafunv2.dbo.shop_info s on c.s_id = s.s_id and s.archive_id = 1
left join hft_erpdb.dbo.FUN_LEASE_HOUSING f on c.house_id = f.SALE_ID and f.INFO_TYPE = 0
WHERE c.sale_lease = 2 and c.house_type not in(3,4)
DELETE c FROM fafunv2.dbo.count_done c
inner join fafunv2.dbo.shop_info s on c.s_id = s.s_id and s.archive_id = 1
left join hft_erpdb.dbo.FUN_LEASE_TRADE f on c.house_id = f.SALE_ID and f.INFO_TYPE = 0
WHERE c.sale_lease = 2 and c.house_type = 3
DELETE c FROM fafunv2.dbo.count_done c
inner join fafunv2.dbo.shop_info s on c.s_id = s.s_id and s.archive_id = 1
left join hft_erpdb.dbo.FUN_LEASE_OFFICE f on c.house_id = f.SALE_ID and f.INFO_TYPE = 0
WHERE c.sale_lease = 2 and c.house_type = 4
UPDATE fafunv2.dbo.shop_info set syn_date = NULL where archive_id = @ArchiveId;
RETURN 0
END

go

