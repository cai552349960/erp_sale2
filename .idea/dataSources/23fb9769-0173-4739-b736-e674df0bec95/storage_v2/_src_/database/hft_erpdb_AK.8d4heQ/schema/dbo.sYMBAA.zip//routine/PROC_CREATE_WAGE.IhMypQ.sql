CREATE PROCEDURE [dbo].[PROC_CREATE_WAGE]
@startTime int,
@endTime int,
@uId int,
@compId int,
@deptId int,
@regId int,
@areaId int,
@pageOffset int,  --传入第几页
@pageSize int, --传入每页大小
@deal_status int
AS
BEGIN
SET NOCOUNT ON;
CREATE TABLE #WAGE_TEMP(T_TIME VARCHAR(20),T_USER_ID INT)
declare @myStartTime int,@myEndTime int
declare @USER_ID int
set @myStartTime=@startTime
set @myEndTime=@endTime
if(@uId>0)
while(@myStartTime<=@myEndTime)
begin
insert into #WAGE_TEMP values((select convert(varchar(7),cast(cast(@myStartTime as varchar)+'01' as datetime),120)),@uId)
set @myStartTime=cast(replace(convert(varchar(7),dateadd(m,1,cast(cast(@myStartTime as varchar)+'01' as datetime)),120),'-','') as int)
end
else if(@areaId>0)
begin
declare myCursor cursor for
select USER_ID from FUN_USERS where  AREA_ID = @areaId and USER_STATUS = 1 and USER_WRITEOFF <> 1
open myCursor
fetch next from myCursor into @USER_ID
while(@@Fetch_Status = 0)
begin
set @myStartTime=@startTime
set @myEndTime=@endTime
while(@myStartTime<=@myEndTime)
begin
insert into #WAGE_TEMP values((select convert(varchar(7),cast(cast(@myStartTime as varchar)+'01' as datetime),120)),@USER_ID)
set @myStartTime=cast(replace(convert(varchar(7),dateadd(m,1,cast(cast(@myStartTime as varchar)+'01' as datetime)),120),'-','') as int)
end
fetch next from myCursor into @USER_ID
end
close myCursor
deallocate myCursor
end
else if(@regId>0)
begin
declare myCursor cursor for
select USER_ID from FUN_USERS where REG_ID = @regId and USER_STATUS = 1 and USER_WRITEOFF <> 1
open myCursor
fetch next from myCursor into @USER_ID
while(@@Fetch_Status = 0)
begin
set @myStartTime=@startTime
set @myEndTime=@endTime
while(@myStartTime<=@myEndTime)
begin
insert into #WAGE_TEMP values((select convert(varchar(7),cast(cast(@myStartTime as varchar)+'01' as datetime),120)),@USER_ID)
set @myStartTime=cast(replace(convert(varchar(7),dateadd(m,1,cast(cast(@myStartTime as varchar)+'01' as datetime)),120),'-','') as int)
end
fetch next from myCursor into @USER_ID
end
close myCursor
deallocate myCursor
end
else if(@deptId>0)
begin
declare myCursor cursor for
select USER_ID from FUN_USERS where DEPT_ID = @deptId and USER_STATUS = 1 and USER_WRITEOFF <> 1
open myCursor
fetch next from myCursor into @USER_ID
while(@@Fetch_Status = 0)
begin
set @myStartTime=@startTime
set @myEndTime=@endTime
while(@myStartTime<=@myEndTime)
begin
insert into #WAGE_TEMP values((select convert(varchar(7),cast(cast(@myStartTime as varchar)+'01' as datetime),120)),@USER_ID)
set @myStartTime=cast(replace(convert(varchar(7),dateadd(m,1,cast(cast(@myStartTime as varchar)+'01' as datetime)),120),'-','') as int)
end
fetch next from myCursor into @USER_ID
end
close myCursor
deallocate myCursor
end
else
begin
declare myCursor cursor for
select USER_ID from FUN_USERS where COMP_ID = @compId and USER_STATUS = 1 and USER_WRITEOFF <> 1
open myCursor
fetch next from myCursor into @USER_ID
while(@@Fetch_Status = 0)
begin
set @myStartTime=@startTime
set @myEndTime=@endTime
while(@myStartTime<=@myEndTime)
begin
insert into #WAGE_TEMP values((select convert(varchar(7),cast(cast(@myStartTime as varchar)+'01' as datetime),120)),@USER_ID)
set @myStartTime=cast(replace(convert(varchar(7),dateadd(m,1,cast(cast(@myStartTime as varchar)+'01' as datetime)),120),'-','') as int)
end
fetch next from myCursor into @USER_ID
end
close myCursor
deallocate myCursor
end
declare
@sql_Str nvarchar(3500),
@start_Num varchar(50),
@end_Num varchar(50),
@count_num int,
@order_By varchar(100)
set @order_By='T_USER_ID, T_TIME'
set @sql_Str='select @a=count(1) from (SELECT A.*,D.*,E.WAGE_ID,E.PROFIT_WAGE,E.WAGE_MONEY,E.OTHER_WAGE,E.DEL_WAGE,E.REAL_WAGE,E.CHECK_STATUS,
H.WAGE_TYPE_EN,H.BASE_MONEY,
(SELECT USER_NAME FROM FUN_USERS WHERE FUN_USERS.USER_ID = A.T_USER_ID) USER_NAME
FROM #WAGE_TEMP A LEFT JOIN
(SELECT CONVERT(CHAR(7) ,DEAL_VERIFY_TIME , 120) _DEAL_VERIFY_TIME,CONVERT(CHAR(10) ,DEAL_VERIFY_TIME , 120) __DEAL_VERIFY_TIME,
CONVERT(CHAR(7) ,SETTLE_TIME , 120) _SETTLE_TIME,CONVERT(CHAR(10) ,SETTLE_TIME , 120) __SETTLE_TIME,
B.DEAL_STATUS,B.HOUSEADDRESS,B.DEAL_TYPE,C.PROFIT_PROPORTION,C.PROFIT_MONEY,C.FLAG,C.USER_ID FROM FUN_DEAL B,FUN_PROFIT C WHERE B.DEAL_ID = C.DEAL_ID
AND C.SETTLE_TIME IS NOT NULL
) D ON A.T_TIME = D._SETTLE_TIME AND A.T_USER_ID = D.USER_ID  AND D.DEAL_STATUS =  '+cast(@deal_status as varchar)+'
LEFT JOIN FUN_WAGE E
ON A.T_USER_ID = E.USER_ID AND  CONVERT(CHAR(7) ,E.CREATE_DATE , 120) = A.T_TIME
LEFT JOIN (SELECT WAGE_TYPE_EN,USER_ID,BASE_MONEY FROM FUN_BASEWAGE F INNER JOIN FUN_WAGE_TYPE G
ON F.WAGETYPE_ID = G.WAGETYPE_ID) H ON A.T_USER_ID = H.USER_ID ) as tmp15'
exec sp_executesql @sql_Str,N'@a int output',@count_num output
set @start_Num = ((@pageOffset*@pageSize)-@pageSize)+1
set @end_Num = @pageOffset*@pageSize
SELECT *,convert(varchar(10), @count_num) as countNum FROM (select *,ROW_NUMBER() Over(order by T_USER_ID, T_TIME) as rowNum FROM
(SELECT A.*,D.*,E.WAGE_ID,E.PROFIT_WAGE,E.WAGE_MONEY,E.OTHER_WAGE,E.DEL_WAGE,E.REAL_WAGE,E.CHECK_STATUS,
H.WAGE_TYPE_EN,H.BASE_MONEY,
(SELECT USER_NAME FROM FUN_USERS WHERE FUN_USERS.USER_ID = A.T_USER_ID) USER_NAME
FROM #WAGE_TEMP A LEFT JOIN
(SELECT CONVERT(CHAR(7) ,DEAL_VERIFY_TIME , 120) _DEAL_VERIFY_TIME,CONVERT(CHAR(10) ,DEAL_VERIFY_TIME , 120) __DEAL_VERIFY_TIME,
CONVERT(CHAR(7) ,SETTLE_TIME , 120) _SETTLE_TIME,CONVERT(CHAR(10) ,SETTLE_TIME , 120) __SETTLE_TIME,
B.DEAL_STATUS,B.HOUSEADDRESS,B.DEAL_TYPE,C.PROFIT_PROPORTION,C.PROFIT_MONEY,C.FLAG,C.USER_ID FROM FUN_DEAL B,FUN_PROFIT C WHERE B.DEAL_ID = C.DEAL_ID
AND C.SETTLE_TIME IS NOT NULL
) D ON A.T_TIME = D._SETTLE_TIME AND A.T_USER_ID = D.USER_ID  AND D.DEAL_STATUS =  @deal_status
LEFT JOIN FUN_WAGE E
ON A.T_USER_ID = E.USER_ID AND  CONVERT(CHAR(7) ,E.CREATE_DATE , 120) = A.T_TIME
LEFT JOIN (SELECT WAGE_TYPE_EN,USER_ID,BASE_MONEY FROM FUN_BASEWAGE F INNER JOIN FUN_WAGE_TYPE G
ON F.WAGETYPE_ID = G.WAGETYPE_ID) H ON A.T_USER_ID = H.USER_ID ) as tmp15) as myTable WHERE rowNum BETWEEN @start_Num and @end_Num
drop table #WAGE_TEMP
END

go

