CREATE procedure [dbo].[proc_sampleSplitPage]  --分页代码存储过程 孔佳
(
@tab_Name varchar(3000),  --传入表名(含where条件)
@order_By varchar(100),   --传入需要排序的字段
@page_No int,             --传入第几页
@page_Size int            --传入每页大小
)
as
BEGIN
declare @sql_Str nvarchar(3500),
@start_Num varchar(50),
@end_Num varchar(50),
@count_num int
set @sql_Str='select @a=count(1) from '+@tab_Name
exec sp_executesql @sql_Str,N'@a int output',@count_num output
set @start_Num = ((@page_No*@page_Size)-@page_Size)+1
set @end_Num = @page_No*@page_Size
set @sql_Str = 'SELECT *,'+convert(varchar(20), @count_num)+' as countNum FROM
(select *,ROW_NUMBER() Over(order by '+@order_By+') as rowNum
FROM '+@tab_Name+' ) as myTable
WHERE rowNum BETWEEN '+@start_Num+' and '+@end_Num;
EXEC sp_executesql @sql_Str;
END

go

