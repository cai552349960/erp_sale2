
-- =============================================
-- Author:		顾灿龙
-- Create date: 2014-02-24
-- Description:	生成房客源NO，规则：2位类型+2位城市编号+YYMMDDHHMM+3位自增序列，共17位房客源编码
-- =============================================

CREATE PROCEDURE [dbo].[proc_GenHouseCustNo]
	@TableName	varchar(20),  --表名
	@CityNo		varchar(10),  --城市编号
	@HouseCustNo varchar(30) = null output
AS

BEGIN
	SET NOCOUNT ON;
	
	DECLARE @NoType VARCHAR(20)
	DECLARE @DATESTR VARCHAR(10)
	DECLARE @SEQ_NUMS INT

	SELECT @NoType = CASE upper(@TableName) 
			WHEN 'FUN_SALE'		THEN 'CS'
			WHEN 'FUN_LEASE'	THEN 'CZ'
			--和表后修改
			--WHEN 'FUN_SALE_HOUSING'		THEN 'SZ'
			--WHEN 'FUN_SALE_TRADE'		THEN 'SS'
			--WHEN 'FUN_SALE_OFFICE'		THEN 'SX'
			--WHEN 'FUN_LEASE_HOUSING'	THEN 'ZZ'
			--WHEN 'FUN_LEASE_TRADE'		THEN 'ZS'
			--WHEN 'FUN_LEASE_OFFICE'		THEN 'ZX'
			WHEN 'FUN_BUY_CUSTOMER'		THEN 'QG'
			WHEN 'FUN_RENT_CUSTOMER'	THEN 'QZ'
			ELSE '' END

	IF @NoType = ''OR ISNULL(@CityNo,'') = '' RETURN ''

	--获取YYMMDDHHMMSS
	SELECT @DATESTR = substring(replace(convert(varchar(20),getdate(),112) + convert(varchar(20),getdate(),108),':',''),3,10)

	--从自增序列获取流水号，该流水号范围001 - 999，循环使用
	SELECT @SEQ_NUMS = NEXT VALUE FOR SQ_HouseCustNo 

	set @HouseCustNo = @NoType + upper(@CityNo) + @DATESTR + substring(convert(varchar(4),1000 + @SEQ_NUMS),2,3)
	SELECT @HouseCustNo AS HouseCustNo
END

go

