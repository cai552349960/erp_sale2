CREATE PROCEDURE [dbo].[proc_SINGLE_COUNT_DATA_NEW]
@Indicators1 int,
@Indicators2 int,
@type varchar(10),
@user_id varchar(30),
@rq1 datetime,
@rq2 datetime,
@compNo varchar(5) = null --营销版才需要公司的编号
AS
BEGIN
SET NOCOUNT ON;
DECLARE @dic_type varchar(100)
DECLARE @dd_value varchar(100)
DECLARE @comcolumn1 varchar(500)
DECLARE @comcolumn2 varchar(500)
DECLARE @comcolumn3 varchar(500)
DECLARE @sql nvarchar(1000)
DECLARE @sql2 nvarchar(1000)
DECLARE @city_id int
DECLARE @dept_id int
DECLARE @table varchar(50)
DECLARE @caseType varchar(100)
DECLARE @con varchar(300)
IF @type = '1'
BEGIN
SET @caseType = ' CASE_TYPE IN (''1'',''5'') '
END
ELSE IF @type = '2'
BEGIN
SET @caseType = ' CASE_TYPE IN (''2'',''6'') '
END
ELSE
BEGIN
SET @caseType = ' CASE_TYPE = '''+@type+''' '
END;
CREATE TABLE #tmp1(seq INT,Indi varchar(50),val_all float,val_dept float,val_user float)
SELECT @city_id = city_id,@dept_id = DEPT_ID FROM FUN_USERS WHERE USER_ID = @user_id
SET @table = 'FUN_ALL_COUNTDATA AS FAC';
SET @con = ' AND FAC.CITY_ID = ' +CONVERT(VARCHAR(10),@city_id) + ' AND CREATE_DATE BETWEEN ''' + convert(varchar(20),@rq1) + ''' AND ''' + convert(varchar(20),@rq2) + ''' AND '+@caseType+' AND HOUSE_USEAGE = ''1''';
SET @dic_type = CASE @Indicators2
when 2 then 'HOUSE_ROUND'
when 3 then 'HOUSE_TYPE'
when 4 then 'HOUSE_USEAGE'
when 5 then 'HOUSE_FITMENT'
when 6 then 'HOUSE_SOURCE'
ELSE '' END
SET @dd_value = CASE @Indicators2
when 2 then 'ROUND'
when 3 then 'HOUSE_TYPE'
when 4 then 'HOUSE_USEAGE'
when 5 then 'FITMENT'
when 6 then 'SOURCE'
ELSE '' END
IF @type = '2' OR @type = '4'
BEGIN
SET @comcolumn1 = CASE @Indicators1
when 1 then ' COUNT(*) as val_all '
when 2 then ' ISNULL(SUM(AREA),0) as val_all '
when 3 then ' ISNULL(AVG(TOTALPRICE),0) as val_all '
when 4 then ' ISNULL(AVG(PRICE/(AREA+1)),0) as val_all '
END
END
ELSE
BEGIN
SET @comcolumn1 = CASE @Indicators1
when 1 then ' COUNT(*) as val_all '
when 2 then ' ISNULL(SUM(AREA),0) as val_all '
when 3 then ' ISNULL(AVG(TOTALPRICE),0) as val_all '
when 4 then ' ISNULL(AVG(PRICE),0) as val_all '
END
END
SET @comcolumn2 = CASE @Indicators1
when 1 then 'ISNULL(SUM(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' THEN 1 ELSE 0 END),0) as val_dept '
when 2 then 'ISNULL(SUM(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' THEN AREA ELSE null END),0) as val_dept '
when 3 then 'ISNULL(AVG(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' THEN TOTALPRICE ELSE null END),0) as val_dept '
when 4 then 'ISNULL(AVG(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' THEN PRICE ELSE null END),0) as val_dept '
END
SET @comcolumn3 = CASE @Indicators1
when 1 then 'ISNULL(SUM(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' AND USER_ID = ' + convert(varchar(10),@user_id) + ' THEN 1 ELSE 0 END ),0) as val_user'
when 2 then 'ISNULL(SUM(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' AND USER_ID = ' + convert(varchar(10),@user_id) + ' THEN AREA ELSE null END ),0) as val_user '
when 3 then 'ISNULL(AVG(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' AND USER_ID = ' + convert(varchar(10),@user_id) + ' THEN TOTALPRICE ELSE null END ),0) as val_user '
when 4 then 'ISNULL(AVG(CASE WHEN DEPT_ID = ' + convert(varchar(10),@dept_id) + ' AND USER_ID = ' + convert(varchar(10),@user_id) + ' THEN PRICE ELSE null END ),0) as val_user '
END
IF @Indicators2 = 1
BEGIN
SET @sql = 'INSERT INTO #tmp1(Indi,val_all,val_dept,val_user) SELECT REG_NAME as Indi,'+ @comcolumn1 +','+ @comcolumn2 +','+ @comcolumn3 +' FROM FUN_REG LEFT JOIN '+@table+' ON REG_ID = FAC.REGION WHERE REG_NAME IS NOT NULL '+ @con +' GROUP BY REG_NAME,SEQ_NO ORDER BY SEQ_NO';
EXEC SP_EXECUTESQL @sql
END
IF @Indicators2 = 4
BEGIN
SET @con = ' AND FAC.CITY_ID = ' +CONVERT(VARCHAR(10),@city_id) + ' AND CREATE_DATE BETWEEN ''' + convert(varchar(20),@rq1) + ''' AND ''' + convert(varchar(20),@rq2) + ''' AND CASE_TYPE = ''' + @type + '''';
END;
IF @Indicators2 > 1 AND @Indicators2 < 7
BEGIN
SET @sql = 'INSERT INTO #tmp1(Indi,val_all,val_dept,val_user) SELECT DDINFO.DIC_CN_MSG as Indi,'+ @comcolumn1 +','+ @comcolumn2 +','+ @comcolumn3 +' FROM DIC_DEFINITIONS AS DDINFO LEFT JOIN '+@table+' ON DIC_TYPE = ''' + @dic_type + ''' AND ' + @dd_value + ' = DIC_VALUE WHERE DDINFO.DIC_CN_MSG IS NOT NULL '+ @con +' GROUP BY DDINFO.DIC_CN_MSG,DDINFO.SEQ_NO ORDER BY DDINFO.SEQ_NO';
EXEC SP_EXECUTESQL @sql
END
IF @Indicators2 < 7
BEGIN
IF @Indicators2 = 1
INSERT #tmp1
SELECT SEQ_NO,REG_NAME,0,0,0 FROM FUN_REG WHERE FUN_REG.CITY_ID = @city_id and REG_NAME NOT IN(SELECT Indi FROM #tmp1 )
ELSE
INSERT #tmp1
SELECT SEQ_NO,DIC_CN_MSG,0,0,0 FROM DIC_DEFINITIONS WHERE  DIC_DEFINITIONS.DIC_TYPE = @dic_type AND DIC_CN_MSG NOT IN(SELECT Indi FROM #tmp1 ) AND DIC_CN_MSG != '均可' AND CITY_ID = @city_id
SELECT * FROM #tmp1
END
IF @Indicators2 = 7
BEGIN
SET @sql = 'INSERT INTO #tmp1(Indi,val_all,val_dept,val_user) SELECT YEAR as Indi,' + @comcolumn1 + ',' + @comcolumn2 + ',' + @comcolumn3 + ' FROM '+@table+' WHERE YEAR > 1990 AND YEAR <= DATEPART(YYYY,GETDATE()) '+ @con +' GROUP BY YEAR ORDER BY YEAR'
EXEC SP_EXECUTESQL @sql
SELECT Indi,val_all,val_dept,val_user FROM #tmp1
END
IF @Indicators2 = 8
BEGIN
SET @sql = 'SELECT 1,''60平米以下'',' +@comcolumn1 + ',' + @comcolumn2 + ',' + @comcolumn3+ ' FROM '+@table+' WHERE AREA < 60 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 2,''60-90平米'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 60 AND AREA < 90'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 3,''90-120平米'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 90 AND AREA < 120'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 4,''120-150平米'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 120 AND AREA < 150'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 5,''150-180平米'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 150 AND AREA < 180'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 6,''180-240平米'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 180 AND AREA < 240'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 7,''240-320平米'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 240 AND AREA < 320'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 8,''320-600平米'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 320 AND AREA < 600'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 9,''600平米以上'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE AREA >= 600'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SELECT Indi,val_all,val_dept,val_user FROM #tmp1 order by seq
END
IF @Indicators2 = 9
BEGIN
IF @type = '1' OR @type = '3'
BEGIN
SET @sql = 'SELECT 1,''3000元/m2以下'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE < 3000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 2,''3000-4000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 3000 AND PRICE < 4000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 3,''4000-5000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 4000 AND PRICE < 5000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 4,''5000-6000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 5000 AND PRICE < 6000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 5,''6000-7000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 6000 AND PRICE < 7000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 6,''7000-9000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 7000 AND PRICE < 9000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 7,''7000-9000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 7000 AND PRICE < 9000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 8,''9000-12000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 9000 AND PRICE < 12000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 9,''12000-20000元/m2'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 12000 AND PRICE < 20000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 10,''20000元/m2以上'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE > 20000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SELECT Indi,val_all,val_dept,val_user FROM #tmp1 order by seq
END
ELSE IF @type = '2' OR @type = '4'
BEGIN
SET @sql = 'SELECT 1,''0-500元/月以下'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE < 500'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 2,''500-800元/月'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 500 AND PRICE < 800'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 3,''800-1100元/月'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 800 AND PRICE < 1100'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 4,''1100-1400元/月'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 1100 AND PRICE < 1400'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 5,''1400-1700元/月'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 1400 AND PRICE < 1700'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 6,''1700-3000元/月'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 1700 AND PRICE < 3000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 7,''3000-4000元/月'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 3000 AND PRICE < 4000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 8,''4000-5000元/月'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 4000 AND PRICE < 5000'+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 9,''5000元/月以上'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE  PRICE >= 5000 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SELECT Indi,val_all,val_dept,val_user FROM #tmp1 order by seq
END
END
IF @Indicators2 = 10
BEGIN
SET @sql = 'SELECT 1,''套一'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE ROOM = 1' + @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 2,''套二'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE ROOM = 2' + @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 3,''套三'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE ROOM = 3' + @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 4,''套四'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE ROOM = 4' + @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 5,''套五'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE ROOM = 5' + @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 6,''其他'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE ROOM > 5' + @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SELECT Indi,val_all,val_dept,val_user FROM #tmp1 order by seq
END
IF @Indicators2 = 11
BEGIN
IF @type = '1' OR @type = '3'
BEGIN
SET @sql = 'SELECT 1,''30万以下'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE < 30 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 2,''30-50万'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 30 AND TOTALPRICE < 50 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 3,''50-70万'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 50 AND TOTALPRICE < 70 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 4,''70-90万'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 70 AND TOTALPRICE < 90 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 5,''90-120万'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 90 AND TOTALPRICE < 120 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 6,''120-150万'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 120 AND TOTALPRICE < 150 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 7,''150-200万'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 150 AND TOTALPRICE < 200 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 8,''200-400万'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 200 AND TOTALPRICE < 400 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 9,''400万以上'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE > 400 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SELECT Indi,val_all,val_dept,val_user FROM #tmp1 order by seq
END
ELSE IF @type = '2' OR @type = '4'
BEGIN
SET @sql = 'SELECT 1,''500元以下'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE < 500 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 2,''500-800元'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 500 AND TOTALPRICE < 800 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 3,''800-1200元'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 800 AND TOTALPRICE < 1200 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 4,''1200-1800元'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 1200 AND TOTALPRICE < 1800 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 5,''1800-2600元'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 1800 AND TOTALPRICE < 2600 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 6,''2600-3200元'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 2600 AND TOTALPRICE < 3200 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 7,''3200-4200元'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 3200 AND TOTALPRICE < 4200 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 8,''4200-8000元'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE >= 4200 AND TOTALPRICE < 8000 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SET @sql = 'SELECT 9,''8000元以上'','+@comcolumn1+','+@comcolumn2+','+@comcolumn3+' FROM '+@table+' WHERE TOTALPRICE > 8000 '+ @con
INSERT #tmp1 EXEC SP_EXECUTESQL @sql
SELECT Indi,val_all,val_dept,val_user FROM #tmp1 order by seq
END
END
DROP TABLE #tmp1;
END

go

