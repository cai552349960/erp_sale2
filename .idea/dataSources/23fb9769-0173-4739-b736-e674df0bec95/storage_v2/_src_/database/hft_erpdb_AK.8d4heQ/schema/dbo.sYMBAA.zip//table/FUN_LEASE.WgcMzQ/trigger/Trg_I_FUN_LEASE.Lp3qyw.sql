
-- =============================================
-- Author:		<Author,,顾灿龙>
-- Create date: <Create Date,2016-8-29>
-- Description:	<Description,记录房源变动日志，为了SOLR同步数据用>
-- =============================================
CREATE TRIGGER [dbo].[Trg_I_FUN_LEASE]
   ON  [dbo].[FUN_LEASE]
   AFTER INSERT
AS 
BEGIN

	SET NOCOUNT ON;

    INSERT hft_admindb..FUN_LEASE_TRANS_INFO(CITY_ID,TABLE_NAME,CASE_ID,DEAL_TYPE,CREATION_TIME)
	SELECT CITY_ID,'FUN_LEASE',LEASE_ID,1 AS DEAL_TYPE,GETDATE() FROM INSERTED

END

go

