create function [dbo].[updateUser](@compId int,@compName VARCHAR(100))
Returns REAL
As
Begin
DECLARE  @areaId INTEGER
DECLARE  @userId INTEGER
DECLARE  @userNUM INTEGER
DECLARE  @areaSEQ_NO INTEGER
IF not EXISTS(SELECT * FROM FUN_AREA where COMP_ID=@compId)
BEGIN
select @userNUM= COUNT (USER_ID)FROM FUN_USERS  where USER_POSITION='GENERAL_MANAGER' and  COMP_ID=@compId and USER_WRITEOFF=0
if @userNUM>1
BEGIN
select top 1 @userId=USER_ID from FUN_USERS where USER_POSITION='GENERAL_MANAGER' and  COMP_ID=@compId and USER_WRITEOFF=0
END
END
Return @userId
End

go

